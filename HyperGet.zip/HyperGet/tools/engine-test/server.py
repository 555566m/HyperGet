#!/usr/bin/env python3
"""Test server: deterministic content, HTTP Range, and fault injection.
GET /file/<bytes>?kill=P&e503=P&throttle=BPS&norange=1&cd=name.bin
GET /redir/<bytes>?...   -> 302 to /file/<bytes>?...
GET /sha/<bytes>         -> sha256 of the content
"""
import hashlib, random, sys, time, socket
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs

BLK = 1 << 20
base = bytearray()
h = b"hyperget"
while len(base) < BLK:
    h = hashlib.sha256(h).digest(); base += h
base = bytes(base[:BLK])
tables = [bytes((i ^ k) & 255 for i in range(256)) for k in range(256)]
blocks = {}

def block(idx):
    b = blocks.get(idx & 255)
    if b is None:
        b = base.translate(tables[idx & 255]); blocks[idx & 255] = b
    return b

def chunk(off, n):
    out = bytearray()
    while n > 0:
        bi, bo = divmod(off, BLK)
        take = min(n, BLK - bo)
        out += block(bi)[bo:bo + take]
        off += take; n -= take
    return bytes(out)

def sha(size):
    m = hashlib.sha256(); off = 0
    while off < size:
        n = min(BLK, size - off); m.update(chunk(off, n)); off += n
    return m.hexdigest()

class H(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    def log_message(self, *a): pass
    def do_HEAD(self): self.do_GET()
    def do_GET(self):
        u = urlparse(self.path); q = {k: v[0] for k, v in parse_qs(u.query).items()}
        parts = u.path.strip("/").split("/")
        try:
            if parts[0] == "sha":
                b = sha(int(parts[1])).encode()
                self.send_response(200); self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b); return
            if parts[0] == "redir":
                self.send_response(302); self.send_header("Location", "/file/" + parts[1] + ("?" + u.query if u.query else "")); self.send_header("Content-Length", "0"); self.end_headers(); return
            size = int(parts[1])
            if random.random() < float(q.get("e503", 0)):
                self.send_response(503); self.send_header("Retry-After", "1"); self.send_header("Content-Length", "0"); self.end_headers(); return
            start, end, status = 0, size - 1, 200
            rng = self.headers.get("Range")
            if rng and not q.get("norange"):
                s, e = rng.replace("bytes=", "").split("-")
                start = int(s); end = int(e) if e else size - 1
                end = min(end, size - 1)
                if start >= size:
                    self.send_response(416); self.send_header("Content-Range", f"bytes */{size}"); self.send_header("Content-Length", "0"); self.end_headers(); return
                status = 206
            n = end - start + 1
            self.send_response(status)
            self.send_header("Content-Type", "application/octet-stream")
            self.send_header("Content-Length", str(n))
            if not q.get("norange"): self.send_header("Accept-Ranges", "bytes")
            self.send_header("ETag", '"v1"')
            if q.get("cd"): self.send_header("Content-Disposition", f'attachment; filename="{q["cd"]}"')
            if status == 206: self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
            self.end_headers()
            kill_at = None
            if random.random() < float(q.get("kill", 0)):
                kill_at = random.randint(100_000, 3_000_000)
            thr = int(q.get("throttle", 0)); sent = 0; off = start; t0 = time.time()
            while sent < n:
                k = min(64 * 1024, n - sent)
                self.wfile.write(chunk(off, k)); off += k; sent += k
                if kill_at is not None and sent >= kill_at:
                    self.connection.shutdown(socket.SHUT_RDWR); self.connection.close(); self.close_connection = True; return
                if thr:
                    ahead = sent / thr - (time.time() - t0)
                    if ahead > 0: time.sleep(ahead)
        except (BrokenPipeError, ConnectionResetError, OSError):
            self.close_connection = True

if __name__ == "__main__":
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8765
    ThreadingHTTPServer.request_queue_size = 128
    ThreadingHTTPServer(("127.0.0.1", port), H).serve_forever()
