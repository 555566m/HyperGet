import com.hyperget.core.*;
import java.io.*;
import java.net.*;
import java.nio.file.*;
import java.util.*;

public class EngineTest {
    static final String BASE = "http://127.0.0.1:8765";
    static int fails = 0;

    static String get(String u) throws Exception {
        try (InputStream in = new URL(u).openStream()) { return new String(in.readAllBytes()).trim(); }
    }

    static DownloadItem wait(DownloadEngine e, DownloadItem it, long maxMs) throws Exception {
        long t0 = System.currentTimeMillis();
        while (System.currentTimeMillis() - t0 < maxMs) {
            if (it.status == DownloadStatus.COMPLETED || it.status == DownloadStatus.FAILED) break;
            Thread.sleep(100);
        }
        return it;
    }

    static void check(String name, DownloadItem it, long size, String expectSha, long t0) throws Exception {
        File f = new File(it.dir, it.fileName);
        String got = it.status == DownloadStatus.COMPLETED && f.exists() ? Util.checksum(f, "SHA-256") : "";
        boolean ok = it.status == DownloadStatus.COMPLETED && f.length() == size && got.equals(expectSha);
        double sec = (System.currentTimeMillis() - t0) / 1000.0;
        System.out.printf("%s %-34s status=%s size=%d %.1fs (%.1f MB/s) %s%n", ok ? "PASS" : "FAIL", name, it.status,
                f.exists() ? f.length() : -1, sec, size / 1048576.0 / Math.max(sec, 0.01), it.error);
        if (!ok) fails++;
        f.delete();
    }

    static DownloadEngine engine(File tmp, String tag, Config c) {
        c.defaultDir = new File(tmp, "dl-" + tag).getAbsolutePath();
        return new DownloadEngine(new File(tmp, "store-" + tag), c, null);
    }

    public static void main(String[] a) throws Exception {
        File tmp = Files.createTempDirectory("hgtest").toFile();
        long MB = 1L << 20;

        // 1 big file, 8 threads, random connection kills + 503s
        {
            long size = 400 * MB; String sha = get(BASE + "/sha/" + size);
            Config c = new Config(); c.defaultThreads = 8;
            DownloadEngine e = engine(tmp, "1", c);
            long t0 = System.currentTimeMillis();
            DownloadItem it = e.add(new DownloadRequest(BASE + "/file/" + size + "?kill=0.5&e503=0.1"));
            wait(e, it, 180_000); check("400MB 8thr kills+503", it, size, sha, t0); e.shutdown();
        }
        // no range support -> single stream
        {
            long size = 60 * MB; String sha = get(BASE + "/sha/" + size);
            DownloadEngine e = engine(tmp, "2", new Config());
            long t0 = System.currentTimeMillis();
            DownloadItem it = e.add(new DownloadRequest(BASE + "/file/" + size + "?norange=1"));
            wait(e, it, 60_000); check("60MB no-range server", it, size, sha, t0); e.shutdown();
        }
        // redirect + content-disposition filename
        {
            long size = 20 * MB; String sha = get(BASE + "/sha/" + size);
            DownloadEngine e = engine(tmp, "3", new Config());
            long t0 = System.currentTimeMillis();
            DownloadItem it = e.add(new DownloadRequest(BASE + "/redir/" + size + "?cd=my%20movie.mkv"));
            wait(e, it, 60_000);
            boolean nameOk = it.fileName.equals("my movie.mkv");
            System.out.println((nameOk ? "PASS" : "FAIL") + " filename from Content-Disposition: " + it.fileName);
            if (!nameOk) fails++;
            check("20MB redirect", it, size, sha, t0); e.shutdown();
        }
        // pause / resume + simulated process death (new engine reads store)
        {
            long size = 240 * MB; String sha = get(BASE + "/sha/" + size);
            Config c = new Config(); c.defaultThreads = 6;
            DownloadEngine e = engine(tmp, "4", c);
            long t0 = System.currentTimeMillis();
            DownloadItem it = e.add(new DownloadRequest(BASE + "/file/" + size + "?throttle=2000000"));
            Thread.sleep(2500);
            e.pause(it.id); Thread.sleep(1500);
            long d1 = it.done;
            System.out.println("INFO paused at " + (d1 / MB) + " MB status=" + it.status);
            e.resumeAll(); e.start(it.id, false); Thread.sleep(2000);
            e.shutdown(); // like app kill: job stops, state persisted
            long d2 = it.done;
            Config c2 = new Config(); c2.defaultDir = c.defaultDir; c2.defaultThreads = 4;
            DownloadEngine e2 = new DownloadEngine(new File(tmp, "store-4"), c2, null);
            DownloadItem it2 = e2.items().get(0);
            System.out.println("INFO reloaded: status=" + it2.status + " done=" + (it2.done / MB) + " MB (was " + (d2 / MB) + ")");
            wait(e2, it2, 120_000); check("240MB pause+restart resume", it2, size, sha, t0);
            if (it2.done < d1 / 2) { System.out.println("FAIL resume lost progress"); fails++; }
            e2.shutdown();
        }
        // network drops (offline 6s mid download) must not fail or restart
        {
            long size = 100 * MB; String sha = get(BASE + "/sha/" + size);
            DownloadEngine e = engine(tmp, "5", new Config());
            long t0 = System.currentTimeMillis();
            DownloadItem it = e.add(new DownloadRequest(BASE + "/file/" + size + "?throttle=1500000"));
            Thread.sleep(1500);
            e.setOnline(false); Thread.sleep(6000);
            System.out.println("INFO offline status=" + it.status);
            e.setOnline(true);
            wait(e, it, 120_000); check("100MB offline 6s then online", it, size, sha, t0); e.shutdown();
        }
        // speed limit
        {
            long size = 30 * MB; String sha = get(BASE + "/sha/" + size);
            Config c = new Config(); c.globalSpeedLimit = 5 * MB;
            DownloadEngine e = engine(tmp, "6", c);
            long t0 = System.currentTimeMillis();
            DownloadItem it = e.add(new DownloadRequest(BASE + "/file/" + size));
            wait(e, it, 60_000);
            double sec = (System.currentTimeMillis() - t0) / 1000.0;
            check("30MB limited to 5MB/s", it, size, sha, t0);
            boolean ok = sec > 4.5 && sec < 9;
            System.out.println((ok ? "PASS" : "FAIL") + " limiter time " + sec + "s (expect ~6s)");
            if (!ok) fails++;
            e.shutdown();
        }
        // many small + queue concurrency
        {
            Config c = new Config(); c.maxConcurrent = 2;
            DownloadEngine e = engine(tmp, "7", c);
            long size = 5 * MB; String sha = get(BASE + "/sha/" + size);
            List<DownloadItem> l = new ArrayList<>();
            long t0 = System.currentTimeMillis();
            for (int i = 0; i < 8; i++) l.add(e.add(new DownloadRequest(BASE + "/file/" + size + "?cd=f" + i + ".bin&kill=0.3")));
            int maxRun = 0;
            while (System.currentTimeMillis() - t0 < 60_000) {
                int run = 0, done = 0;
                for (DownloadItem i : l) { if (i.status.isRunning()) run++; if (i.status == DownloadStatus.COMPLETED) done++; }
                maxRun = Math.max(maxRun, run);
                if (done == l.size()) break;
                Thread.sleep(50);
            }
            boolean ok = maxRun <= 2;
            System.out.println((ok ? "PASS" : "FAIL") + " max concurrent=" + maxRun);
            if (!ok) fails++;
            int n = 0; for (DownloadItem i : l) { check("queue item " + (n++), i, size, sha, t0); }
            e.shutdown();
        }
        // unreachable server -> waits, eventually FAILED w/ short giveUp
        {
            Config c = new Config(); c.giveUpAfterMs = 3000; c.autoRetryFailed = false;
            DownloadEngine e = engine(tmp, "8", c);
            DownloadItem it = e.add(new DownloadRequest("http://127.0.0.1:9/nothing.bin"));
            wait(e, it, 60_000);
            boolean ok = it.status == DownloadStatus.FAILED;
            System.out.println((ok ? "PASS" : "FAIL") + " unreachable -> " + it.status + " (" + it.error + ")");
            if (!ok) fails++;
            e.shutdown();
        }
        System.out.println(fails == 0 ? "ALL TESTS PASSED" : (fails + " TEST(S) FAILED"));
        System.exit(fails == 0 ? 0 : 1);
    }
}
