#!/usr/bin/env python3
"""Renders glossy 3D-style icons (lit height-field shading) into app/src/main/res/drawable-nodpi."""
import math, os, sys
import numpy as np
from PIL import Image, ImageDraw, ImageFilter

S = 512
OUT = sys.argv[1] if len(sys.argv) > 1 else "out"
os.makedirs(OUT, exist_ok=True)

def blur(a, r):
    im = Image.fromarray((np.clip(a, 0, 1) * 255).astype(np.uint8))
    return np.asarray(im.filter(ImageFilter.GaussianBlur(r)), dtype=np.float32) / 255.0

def new():
    im = Image.new("L", (S, S), 0)
    return im, ImageDraw.Draw(im)

def arr(im):
    return np.asarray(im, dtype=np.float32) / 255.0

def soften(m, r=7):
    """round all corners: blur then re-threshold with a smooth ramp."""
    b = blur(m, r)
    return np.clip((b - 0.5) * 6 + 0.5, 0, 1)

def hexc(h):
    h = h.lstrip("#"); return np.array([int(h[i:i+2], 16) for i in (0, 2, 4)], np.float32) / 255

L = np.array([-0.45, -0.65, 0.62], np.float32); L /= np.linalg.norm(L)
Hh = L + np.array([0, 0, 1], np.float32); Hh /= np.linalg.norm(Hh)

def shade(mask, top, bottom, blur_r, hscale, shin=40, spec=0.55, amb=0.55):
    h = blur(mask, blur_r) * hscale
    gy, gx = np.gradient(h)
    n = np.stack([-gx, -gy, np.ones_like(h)], -1)
    n /= np.linalg.norm(n, axis=-1, keepdims=True)
    diff = np.clip((n * L).sum(-1), 0, 1)
    sp = np.clip((n * Hh).sum(-1), 0, 1) ** shin
    t = np.linspace(0, 1, S, dtype=np.float32)[:, None, None]
    base = hexc(top)[None, None, :] * (1 - t) + hexc(bottom)[None, None, :] * t
    rim = (1 - n[..., 2:3]) ** 1.5
    col = base * (amb + 0.7 * diff[..., None]) + sp[..., None] * spec + rim * 0.12 * hexc(top)
    return np.clip(col, 0, 1)

def over(dst, src_rgb, alpha):
    a = alpha[..., None]
    dst[..., :3] = dst[..., :3] * (1 - a) + src_rgb * a
    dst[..., 3:4] = dst[..., 3:4] + a * (1 - dst[..., 3:4])

def shadow(canvas, mask, dx, dy, r, k):
    m = np.roll(np.roll(mask, dy, 0), dx, 1)
    a = blur(m, r) * k
    sh = np.zeros_like(canvas[..., :3])
    over(canvas, sh, a * (1 - canvas[..., 3]))

def tile_mask(inset=36, rad=120):
    im, d = new()
    d.rounded_rectangle([inset, inset, S - inset, S - inset], rad, fill=255)
    return arr(im)

def render(name, glyph_fn, top, bottom, glyph_top="#ffffff", glyph_bottom="#dfe6f2", size=256, tile=True):
    canvas = np.zeros((S, S, 4), np.float32)
    tm = tile_mask()
    shadow(canvas, tm, 0, 18, 18, 0.55)
    rgb = shade(tm, top, bottom, 26, 46)
    # tile alpha antialias
    over(canvas, rgb, tm)
    gm = soften(glyph_fn(), 5)
    # glyph drop shadow, clipped to tile
    sm = np.roll(blur(gm, 7), 12, 0) * 0.5 * tm
    over(canvas, np.zeros((S, S, 3), np.float32), sm)
    grgb = shade(gm, glyph_top, glyph_bottom, 9, 16, shin=60, spec=0.7, amb=0.62)
    over(canvas, grgb, gm)
    img = Image.fromarray((np.clip(canvas, 0, 1) * 255).astype(np.uint8), "RGBA").resize((size, size), Image.LANCZOS)
    img.save(os.path.join(OUT, name + ".png"), optimize=True)
    return img

C = S // 2
def poly(pts, fill=255, d=None): d.polygon(pts, fill=fill)
def thick(d, pts, w, fill=255):
    d.line(pts, fill=fill, width=w, joint="curve")
    for p in (pts[0], pts[-1]):
        d.ellipse([p[0] - w / 2, p[1] - w / 2, p[0] + w / 2, p[1] + w / 2], fill=fill)
def ring(d, box, w, fill=255):
    d.ellipse(box, fill=fill)
    d.ellipse([box[0] + w, box[1] + w, box[2] - w, box[3] - w], fill=0)

# ------------------------------------------------------------------ glyphs
def g_download():
    im, d = new()
    poly([(C - 38, 120), (C + 38, 120), (C + 38, 245), (C + 92, 245), (C, 345), (C - 92, 245), (C - 38, 245)], d=d)
    d.rounded_rectangle([118, 370, 394, 405], 16, fill=255)
    d.rectangle([118, 340, 150, 405], fill=255); d.rectangle([362, 340, 394, 405], fill=255)
    return arr(im)
def g_pause():
    im, d = new()
    d.rounded_rectangle([150, 120, 225, 392], 22, fill=255); d.rounded_rectangle([287, 120, 362, 392], 22, fill=255)
    return arr(im)
def g_play():
    im, d = new(); poly([(170, 112), (170, 400), (405, 256)], d=d); return arr(im)
def g_stop():
    im, d = new(); d.rounded_rectangle([140, 140, 372, 372], 36, fill=255); return arr(im)
def g_queue():
    im, d = new()
    for i, y in enumerate((150, 236, 322)):
        d.ellipse([112, y, 152, y + 40], fill=255); d.rounded_rectangle([182, y + 3, 400, y + 37], 17, fill=255)
    return arr(im)
def g_folder():
    im, d = new()
    d.rounded_rectangle([105, 150, 250, 230], 24, fill=255)
    d.rounded_rectangle([105, 185, 407, 375], 30, fill=255)
    d.rounded_rectangle([105, 185, 407, 205], 6, fill=0)
    return arr(im)
def g_globe():
    im, d = new()
    ring(d, [112, 112, 400, 400], 26)
    d.ellipse([196, 112, 316, 400], fill=255); d.ellipse([220, 112, 292, 400], fill=0)
    d.rectangle([112, 243, 400, 269], fill=255)
    d.rectangle([150, 175, 362, 195], fill=255); d.rectangle([150, 317, 362, 337], fill=255)
    m = Image.new("L", (S, S), 0); ImageDraw.Draw(m).ellipse([112, 112, 400, 400], fill=255)
    return np.minimum(arr(im), arr(m))
def g_magnet():
    im, d = new()
    d.pieslice([120, 120, 392, 392], 180, 360, fill=255)
    d.rectangle([120, 256, 392, 330], fill=255)
    d.pieslice([185, 185, 327, 327], 180, 360, fill=0); d.rectangle([185, 256, 327, 340], fill=0)
    d.rectangle([120, 330, 185, 400], fill=255); d.rectangle([327, 330, 392, 400], fill=255)
    d.rectangle([120, 345, 185, 362], fill=0); d.rectangle([327, 345, 392, 362], fill=0)
    return arr(im)
def g_clock():
    im, d = new(); ring(d, [105, 105, 407, 407], 30)
    thick(d, [(256, 256), (256, 160)], 26); thick(d, [(256, 256), (330, 292)], 26)
    return arr(im)
def g_speed():
    im, d = new()
    d.arc([112, 130, 400, 418], 150, 390, fill=255, width=42)
    for a in (150, 390):
        x = 256 + 123 * math.cos(math.radians(a)); y = 274 + 123 * math.sin(math.radians(a))
        d.ellipse([x - 21, y - 21, x + 21, y + 21], fill=255)
    poly([(256 - 18, 274), (256 + 18, 274), (330, 175)], d=d)
    d.ellipse([256 - 36, 274 - 36, 256 + 36, 274 + 36], fill=255)
    return arr(im)
def g_gear():
    im, d = new()
    d.ellipse([128, 128, 384, 384], fill=255)
    for i in range(8):
        a = math.radians(i * 45)
        cx, cy = C + 135 * math.cos(a), C + 135 * math.sin(a)
        pts = []
        for dx, dy in ((-34, -30), (34, -30), (34, 30), (-34, 30)):
            pts.append((cx + dx * math.cos(a) - dy * math.sin(a) - 10 * math.cos(a), cy + dx * math.sin(a) + dy * math.cos(a) - 10 * math.sin(a)))
        d.polygon(pts, fill=255)
    d.ellipse([C - 58, C - 58, C + 58, C + 58], fill=0)
    return arr(im)
def g_bell():
    im, d = new()
    d.ellipse([150, 120, 362, 330], fill=255)
    d.polygon([(150, 225), (362, 225), (400, 345), (112, 345)], fill=255)
    d.rounded_rectangle([105, 330, 407, 362], 16, fill=255)
    d.ellipse([220, 365, 292, 420], fill=255); d.ellipse([236, 98, 276, 138], fill=255)
    return arr(im)
def g_palette():
    im, d = new()
    d.ellipse([100, 110, 412, 400], fill=255)
    d.ellipse([285, 285, 405, 405], fill=0)
    for (x, y) in ((170, 230), (230, 160), (310, 170), (355, 235)):
        d.ellipse([x - 24, y - 24, x + 24, y + 24], fill=0)
    return arr(im)
def g_link():
    im, d = new()
    for off in (-1, 1):
        t = Image.new("L", (S, S), 0); td = ImageDraw.Draw(t)
        cx = C + off * 62
        td.rounded_rectangle([cx - 100, C - 60, cx + 100, C + 60], 60, fill=255)
        td.rounded_rectangle([cx - 66, C - 28, cx + 66, C + 28], 28, fill=0)
        t = t.rotate(-45, resample=Image.BICUBIC, center=(C, C))
        im.paste(255, mask=t)
    return arr(im)
def g_trash():
    im, d = new()
    d.rounded_rectangle([140, 190, 372, 400], 26, fill=255)
    d.rounded_rectangle([115, 150, 397, 188], 14, fill=255)
    d.rounded_rectangle([205, 112, 307, 160], 14, fill=255)
    d.rounded_rectangle([205, 124, 307, 150], 8, fill=0)
    for x in (200, 244, 288): d.rounded_rectangle([x, 220, x + 24, 370], 10, fill=0)
    return arr(im)
def g_share():
    im, d = new()
    P = [(150, 256), (350, 150), (350, 362)]
    thick(d, [P[0], P[1]], 26); thick(d, [P[0], P[2]], 26)
    for (x, y) in P: d.ellipse([x - 52, y - 52, x + 52, y + 52], fill=255)
    return arr(im)
def g_check():
    im, d = new(); thick(d, [(130, 270), (220, 360), (390, 160)], 58); return arr(im)
def g_error():
    im, d = new()
    d.ellipse([105, 105, 407, 407], fill=255)
    d.rounded_rectangle([232, 160, 280, 285], 22, fill=0); d.ellipse([228, 310, 284, 366], fill=0)
    return arr(im)
def g_search():
    im, d = new(); ring(d, [110, 110, 330, 330], 40); thick(d, [(300, 300), (395, 395)], 52); return arr(im)
def g_plus():
    im, d = new()
    d.rounded_rectangle([225, 120, 287, 392], 28, fill=255); d.rounded_rectangle([120, 225, 392, 287], 28, fill=255); return arr(im)
def g_chart():
    im, d = new()
    for i, h in enumerate((110, 180, 250, 320)):
        x = 112 + i * 75
        d.rounded_rectangle([x, 400 - h, x + 56, 400], 14, fill=255)
    return arr(im)
def g_wifi():
    im, d = new()
    for r in (150, 100, 50):
        d.arc([C - r, 330 - r, C + r, 330 + r], 225, 315, fill=255, width=34)
    d.ellipse([C - 28, 330 - 28 + 40, C + 28, 330 + 28 + 40], fill=255)
    return arr(im)
def g_battery():
    im, d = new()
    d.rounded_rectangle([100, 170, 400, 342], 36, fill=255); d.rounded_rectangle([404, 220, 432, 292], 10, fill=255)
    d.rounded_rectangle([124, 194, 376, 318], 18, fill=0); d.rounded_rectangle([138, 208, 290, 304], 10, fill=255)
    return arr(im)
def g_video():
    im, d = new()
    d.rounded_rectangle([100, 155, 335, 357], 40, fill=255); d.polygon([(330, 235), (415, 170), (415, 342), (330, 277)], fill=255)
    return arr(im)
def g_audio():
    im, d = new()
    d.polygon([(220, 130), (370, 105), (370, 175), (250, 200)], fill=255)
    d.rectangle([225, 130, 258, 355], fill=255); d.rectangle([337, 105, 370, 320], fill=255)
    d.ellipse([140, 310, 258, 410], fill=255); d.ellipse([252, 275, 370, 375], fill=255)
    return arr(im)
def g_image():
    im, d = new()
    d.rounded_rectangle([105, 125, 407, 387], 34, fill=255)
    d.rounded_rectangle([130, 150, 382, 362], 18, fill=0)
    d.polygon([(130, 340), (220, 230), (285, 310), (325, 265), (382, 340), (382, 362), (130, 362)], fill=255)
    d.ellipse([290, 175, 346, 231], fill=255)
    return arr(im)
def g_archive():
    im, d = new()
    d.rounded_rectangle([115, 130, 397, 392], 30, fill=255)
    for i in range(6):
        y = 130 + i * 40
        d.rectangle([C - 26, y, C, y + 20], fill=0 if i % 2 == 0 else 255); d.rectangle([C, y, C + 26, y + 20], fill=255 if i % 2 == 0 else 0)
    d.rounded_rectangle([C - 34, 330, C + 34, 392], 12, fill=0)
    return arr(im)
def _page(d, fold=True):
    d.polygon([(135, 108), (305, 108), (385, 188), (385, 404), (135, 404)], fill=255)
    d.rounded_rectangle([135, 108, 385, 404], 28, fill=255) if not fold else None
def g_doc():
    im, d = new(); _page(d)
    d.polygon([(305, 108), (305, 188), (385, 188)], fill=0)
    for y in (240, 290, 340): d.rounded_rectangle([175, y, 345, y + 24], 10, fill=0)
    return arr(im)
def g_file():
    im, d = new(); _page(d); d.polygon([(305, 108), (305, 188), (385, 188)], fill=0); return arr(im)
def g_apk():
    im, d = new()
    d.pieslice([130, 150, 382, 402], 180, 360, fill=255); d.rounded_rectangle([130, 276, 382, 372], 20, fill=255)
    thick(d, [(185, 190), (150, 130)], 22); thick(d, [(327, 190), (362, 130)], 22)
    d.ellipse([195, 235, 235, 275], fill=0); d.ellipse([277, 235, 317, 275], fill=0)
    return arr(im)
def g_download_small():
    return g_download()
def g_lock():
    im, d = new()
    d.rounded_rectangle([130, 230, 382, 400], 34, fill=255)
    d.arc([175, 110, 337, 300], 180, 360, fill=255, width=40); d.rectangle([175, 205, 215, 250], fill=255); d.rectangle([297, 205, 337, 250], fill=255)
    d.ellipse([228, 285, 284, 341], fill=0); d.rectangle([248, 320, 264, 370], fill=0)
    return arr(im)
def g_bolt():
    im, d = new(); d.polygon([(300, 100), (150, 285), (240, 285), (205, 412), (365, 215), (272, 215)], fill=255); return arr(im)

ICONS = [
 ("download", g_download, "#5ec8ff", "#1670e8"), ("pause", g_pause, "#ffc15a", "#f0701a"),
 ("play", g_play, "#6ee58a", "#14a24a"), ("stop", g_stop, "#ff7a7a", "#d2253a"),
 ("queue", g_queue, "#b99bff", "#6a3fe0"), ("folder", g_folder, "#ffd25e", "#ee9a12"),
 ("browser", g_globe, "#4fe3d2", "#0a8f9c"), ("torrent", g_magnet, "#ff8a7a", "#c42a52"),
 ("scheduler", g_clock, "#c58bff", "#7a2fd0"), ("speed", g_speed, "#c6ef5a", "#4f9d12"),
 ("settings", g_gear, "#9fb2cc", "#4a5a78"), ("notify", g_bell, "#ffd95e", "#e8860f"),
 ("theme", g_palette, "#ff8ac6", "#c8266f"), ("link", g_link, "#6fb4ff", "#2a52d8"),
 ("trash", g_trash, "#ff8a7a", "#c42a30"), ("share", g_share, "#5fe0ff", "#1488c8"),
 ("check", g_check, "#74e895", "#169a50"), ("error", g_error, "#ff8080", "#c8202c"),
 ("search", g_search, "#8fa4ff", "#3a46d0"), ("add", g_plus, "#58e8b0", "#0f9a6a"),
 ("stats", g_chart, "#ff8fe0", "#a02cc0"), ("wifi", g_wifi, "#6fd0ff", "#1d78d8"),
 ("battery", g_battery, "#8ae86a", "#2d9a2d"), ("video", g_video, "#ff9a6a", "#d8381e"),
 ("audio", g_audio, "#c493ff", "#7a35d8"), ("image", g_image, "#5fe6d0", "#12908a"),
 ("archive", g_archive, "#ffc866", "#d9780f"), ("doc", g_doc, "#78b4ff", "#2a5ad0"),
 ("apk", g_apk, "#8ee86a", "#2f9a3a"), ("file", g_file, "#b4c0d4", "#5a6a88"),
 ("lock", g_lock, "#ffb870", "#d85a1e"), ("bolt", g_bolt, "#ffe35e", "#f08a10"),
]
if __name__ == "__main__":
    sheet = Image.new("RGBA", (6 * 200, ((len(ICONS) + 5) // 6) * 200), (24, 26, 36, 255))
    for i, (n, fn, t, b) in enumerate(ICONS):
        im = render("ic3d_" + n, fn, t, b)
        sheet.alpha_composite(im.resize((190, 190), Image.LANCZOS), ((i % 6) * 200 + 5, (i // 6) * 200 + 5))
    sheet.save(os.path.join(OUT, "_sheet.png"))
    print("rendered", len(ICONS))
