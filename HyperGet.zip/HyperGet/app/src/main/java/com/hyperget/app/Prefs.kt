package com.hyperget.app

import android.content.Context
import android.os.Build
import android.os.Environment
import com.hyperget.core.Config
import java.io.File

class Prefs(private val ctx: Context) {
    private val sp = ctx.getSharedPreferences("hyperget", Context.MODE_PRIVATE)

    private fun i(k: String, d: Int) = sp.getInt(k, d)
    private fun b(k: String, d: Boolean) = sp.getBoolean(k, d)
    private fun s(k: String, d: String) = sp.getString(k, d) ?: d

    var threads: Int get() = i("threads", 8); set(v) = sp.edit().putInt("threads", v).apply()
    var maxConcurrent: Int get() = i("maxConcurrent", 3); set(v) = sp.edit().putInt("maxConcurrent", v).apply()
    var speedLimitKb: Int get() = i("speedLimitKb", 0); set(v) = sp.edit().putInt("speedLimitKb", v).apply()
    var wifiOnly: Boolean get() = b("wifiOnly", false); set(v) = sp.edit().putBoolean("wifiOnly", v).apply()
    var autoRetry: Boolean get() = b("autoRetry", true); set(v) = sp.edit().putBoolean("autoRetry", v).apply()
    var giveUpMin: Int get() = i("giveUpMin", 20); set(v) = sp.edit().putInt("giveUpMin", v).apply()
    var preallocate: Boolean get() = b("preallocate", true); set(v) = sp.edit().putBoolean("preallocate", v).apply()
    var insecureSsl: Boolean get() = b("insecureSsl", false); set(v) = sp.edit().putBoolean("insecureSsl", v).apply()
    var overwrite: Boolean get() = b("overwrite", false); set(v) = sp.edit().putBoolean("overwrite", v).apply()
    var proxyHost: String get() = s("proxyHost", ""); set(v) = sp.edit().putString("proxyHost", v).apply()
    var proxyPort: Int get() = i("proxyPort", 0); set(v) = sp.edit().putInt("proxyPort", v).apply()
    var userAgent: String get() = s("userAgent", ""); set(v) = sp.edit().putString("userAgent", v).apply()
    var downloadDir: String get() = s("downloadDir", ""); set(v) = sp.edit().putString("downloadDir", v).apply()
    var clipboardWatch: Boolean get() = b("clipboardWatch", true); set(v) = sp.edit().putBoolean("clipboardWatch", v).apply()
    var notifySound: Boolean get() = b("notifySound", true); set(v) = sp.edit().putBoolean("notifySound", v).apply()
    var notifyVibrate: Boolean get() = b("notifyVibrate", false); set(v) = sp.edit().putBoolean("notifyVibrate", v).apply()
    var theme: Int get() = i("theme", 1); set(v) = sp.edit().putInt("theme", v).apply()      // 0 system, 1 dark, 2 light
    var accent: Int get() = i("accent", 0); set(v) = sp.edit().putInt("accent", v).apply()
    var minBattery: Int get() = i("minBattery", 0); set(v) = sp.edit().putInt("minBattery", v).apply()
    var schedEnabled: Boolean get() = b("schedEnabled", false); set(v) = sp.edit().putBoolean("schedEnabled", v).apply()
    var schedStart: Int get() = i("schedStart", 2 * 60); set(v) = sp.edit().putInt("schedStart", v).apply()
    var schedStop: Int get() = i("schedStop", 7 * 60); set(v) = sp.edit().putInt("schedStop", v).apply()
    var askedStorage: Boolean get() = b("askedStorage", false); set(v) = sp.edit().putBoolean("askedStorage", v).apply()
    var homePage: String get() = s("homePage", "https://www.google.com"); set(v) = sp.edit().putString("homePage", v).apply()

    fun dir(): String {
        val d = downloadDir
        return if (d.isNotBlank()) d else Storage.defaultDir(ctx).absolutePath
    }

    fun apply(c: Config) {
        c.defaultThreads = threads.coerceIn(1, 32)
        c.maxConcurrent = maxConcurrent.coerceIn(1, 10)
        c.globalSpeedLimit = speedLimitKb * 1024L
        c.autoRetryFailed = autoRetry
        c.giveUpAfterMs = giveUpMin * 60_000L
        c.preallocate = preallocate
        c.allowInsecureSsl = insecureSsl
        c.conflict = if (overwrite) com.hyperget.core.ConflictPolicy.OVERWRITE else com.hyperget.core.ConflictPolicy.RENAME
        c.proxyHost = proxyHost
        c.proxyPort = proxyPort
        if (userAgent.isNotBlank()) c.userAgent = userAgent
        c.defaultDir = dir()
    }
}

object Storage {
    fun hasAllFiles(): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager() else true

    fun defaultDir(ctx: Context): File {
        val pub = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "HyperGet")
        if (hasAllFiles()) {
            try {
                if (pub.exists() || pub.mkdirs()) return pub
            } catch (_: Throwable) { }
        }
        val app = ctx.getExternalFilesDir(null) ?: ctx.filesDir
        return File(app, "Downloads").also { it.mkdirs() }
    }
}
