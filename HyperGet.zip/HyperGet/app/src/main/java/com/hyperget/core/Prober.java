package com.hyperget.core;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Finds out size, range support, file name and validators of a URL. */
final class Prober {
    private Prober() {}

    static final class Result {
        long total = -1;
        boolean resumable;
        String finalUrl, fileName = "", mime = "", etag = "", lastModified = "";
        /** For servers that ignore Range: the already-open full response, reused as the single stream. */
        Http.Response stream;
    }

    private static final Pattern CR = Pattern.compile("bytes\\s+(\\d+|\\*)-?(\\d*)/(\\d+|\\*)");

    static Result probe(DownloadItem it, Config cfg, String url) throws IOException {
        Http.Response r = Http.get(cfg, it, url, 0, 0, null);
        HttpURLConnection c = r.conn;
        Result res = new Result();
        res.finalUrl = r.url;
        boolean keep = false;
        try {
            int code = r.code;
            res.mime = nz(c.getContentType());
            res.etag = nz(c.getHeaderField("ETag"));
            res.lastModified = nz(c.getHeaderField("Last-Modified"));
            String name = Util.fileNameFromDisposition(c.getHeaderField("Content-Disposition"));
            if (name == null || name.isEmpty()) name = Util.fileNameFromUrl(r.url);
            res.fileName = name == null ? "" : name;
            if (code == 206) {
                Matcher m = CR.matcher(nz(c.getHeaderField("Content-Range")));
                if (m.find() && !m.group(3).equals("*")) {
                    res.total = Long.parseLong(m.group(3));
                    res.resumable = res.total > 0;
                }
            } else if (code == 200) {
                res.total = c.getContentLengthLong();
                res.resumable = false;
                res.stream = r;
                keep = true;
            } else if (code == 416) {
                String cr = nz(c.getHeaderField("Content-Range"));
                Matcher m = CR.matcher(cr);
                if (m.find() && !m.group(3).equals("*") && Long.parseLong(m.group(3)) == 0) {
                    res.total = 0;
                } else {
                    // Range not satisfiable for a 1-byte probe: retry without Range
                    r.close();
                    Http.Response r2 = Http.get(cfg, it, url, -1, -1, null);
                    if (r2.code != 200) {
                        int cc = r2.code;
                        long ra = Http.retryAfterMs(r2.conn);
                        r2.close();
                        throw new Errors.HttpStatusException(cc, ra);
                    }
                    res.total = r2.conn.getContentLengthLong();
                    res.stream = r2;
                    res.finalUrl = r2.url;
                    keep = true;
                }
            } else {
                throw new Errors.HttpStatusException(code, Http.retryAfterMs(c));
            }
            return res;
        } finally {
            if (!keep) r.close();
        }
    }

    private static String nz(String s) {
        return s == null ? "" : s;
    }
}
