package com.hyperget.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import java.util.Calendar

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        // Application.onCreate already restored the queue, started the engine and (if needed) the service.
        HyperApp.instance.applyPrefs()
    }
}

class ScheduleReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val app = HyperApp.instance
        when (intent.action) {
            Scheduler.ACTION_START -> { app.engine.resumeAll(); app.startServiceSafe() }
            Scheduler.ACTION_STOP -> app.engine.pauseAll()
        }
        Scheduler.apply(ctx)
    }
}

/** Daily start/stop window using AlarmManager (works with the app closed). */
object Scheduler {
    const val ACTION_START = "com.hyperget.SCHED_START"
    const val ACTION_STOP = "com.hyperget.SCHED_STOP"

    private fun pi(ctx: Context, action: String, code: Int) = PendingIntent.getBroadcast(
        ctx, code, Intent(ctx, ScheduleReceiver::class.java).setAction(action),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    private fun nextAt(minutes: Int): Long {
        val c = Calendar.getInstance()
        c.set(Calendar.HOUR_OF_DAY, minutes / 60); c.set(Calendar.MINUTE, minutes % 60)
        c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
        if (c.timeInMillis <= System.currentTimeMillis() + 1000) c.add(Calendar.DAY_OF_YEAR, 1)
        return c.timeInMillis
    }

    fun insideWindow(p: Prefs): Boolean {
        val c = Calendar.getInstance()
        val now = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
        val s = p.schedStart; val e = p.schedStop
        return if (s <= e) now in s until e else (now >= s || now < e)
    }

    fun apply(ctx: Context) {
        val app = ctx.applicationContext as? HyperApp ?: HyperApp.instance
        val p = app.prefs
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pi(ctx, ACTION_START, 11)); am.cancel(pi(ctx, ACTION_STOP, 12))
        if (!p.schedEnabled) return
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, nextAt(p.schedStart), pi(ctx, ACTION_START, 11))
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, nextAt(p.schedStop), pi(ctx, ACTION_STOP, 12))
    }
}
