package com.hyperget.core;

/** Token-bucket style limiter shared by all threads that use the same instance. */
final class RateLimiter {
    private long nextFree = System.nanoTime();

    /** @return nanoseconds the caller should wait before continuing. */
    synchronized long reserve(long bytes, long bytesPerSecond) {
        if (bytesPerSecond <= 0) {
            nextFree = System.nanoTime();
            return 0;
        }
        long now = System.nanoTime();
        if (nextFree < now - 250_000_000L) nextFree = now - 250_000_000L; // allow a small burst
        nextFree += (long) (bytes * 1_000_000_000.0 / bytesPerSecond);
        return Math.max(0, nextFree - now);
    }
}
