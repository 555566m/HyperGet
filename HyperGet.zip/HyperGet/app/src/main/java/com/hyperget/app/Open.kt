package com.hyperget.app

import android.content.Context
import android.content.Intent
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File

object Open {
    fun mime(f: File): String {
        val ext = f.extension.lowercase()
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: when (ext) {
            "apk" -> "application/vnd.android.package-archive"
            "mkv" -> "video/x-matroska"
            else -> "*/*"
        }
    }

    fun uri(ctx: Context, f: File) = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)

    fun viewIntent(ctx: Context, f: File): Intent? {
        if (!f.exists()) return null
        return try {
            Intent(Intent.ACTION_VIEW).setDataAndType(uri(ctx, f), mime(f))
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        } catch (_: Throwable) { null }
    }

    fun file(ctx: Context, f: File) {
        val i = viewIntent(ctx, f)
        if (i == null) { Toast.makeText(ctx, "File not found", Toast.LENGTH_SHORT).show(); return }
        try { ctx.startActivity(i) } catch (_: Throwable) { Toast.makeText(ctx, "No app can open this file", Toast.LENGTH_SHORT).show() }
    }

    fun share(ctx: Context, f: File) {
        if (!f.exists()) { Toast.makeText(ctx, "File not found", Toast.LENGTH_SHORT).show(); return }
        try {
            val i = Intent(Intent.ACTION_SEND).setType(mime(f)).putExtra(Intent.EXTRA_STREAM, uri(ctx, f))
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            ctx.startActivity(Intent.createChooser(i, "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Throwable) { }
    }
}
