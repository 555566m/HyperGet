package com.hyperget.core;

import java.util.HashMap;
import java.util.Map;

public final class DownloadRequest {
    public String url = "", fileName = "", dir = "", referer = "", cookie = "", userAgent = "",
            authUser = "", authPass = "", mirrors = "", checksum = "";
    public Map<String, String> headers = new HashMap<>();
    public int threads = 0, speedLimit = 0;
    public boolean startNow = true;

    public DownloadRequest(String url) {
        this.url = url;
    }
}
