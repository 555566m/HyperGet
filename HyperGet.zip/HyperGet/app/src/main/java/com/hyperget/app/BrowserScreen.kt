package com.hyperget.app

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.webkit.CookieManager
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView

data class MediaHit(val url: String, val label: String)

/** Holds the WebView for the whole activity so tabs/pages survive switching screens. */
@SuppressLint("SetJavaScriptEnabled")
class BrowserState(ctx: Context, private val onDownload: (AddPrefill) -> Unit) {
    val web = WebView(ctx)
    var url by mutableStateOf("")
    var progress by mutableIntStateOf(0)
    var canBack by mutableStateOf(false)
    val media = mutableStateListOf<MediaHit>()
    private val mediaRe = Regex("(?i)\\.(mp4|m4v|webm|mkv|mp3|m4a|aac|flac|ogg|mov)(\\?|$)")

    init {
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.loadWithOverviewMode = true
        web.settings.useWideViewPort = true
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)
        web.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView, u: String, favicon: Bitmap?) {
                url = u; media.clear(); canBack = view.canGoBack()
            }
            override fun onPageFinished(view: WebView, u: String) { url = u; canBack = view.canGoBack() }
            override fun doUpdateVisitedHistory(view: WebView, u: String, isReload: Boolean) { url = u; canBack = view.canGoBack() }
            override fun shouldInterceptRequest(view: WebView, req: WebResourceRequest): WebResourceResponse? {
                val u = req.url.toString()
                if (mediaRe.containsMatchIn(u)) {
                    web.post {
                        if (media.none { it.url == u } && media.size < 30) {
                            media.add(MediaHit(u, URLUtil.guessFileName(u, null, null)))
                        }
                    }
                }
                return null
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, p: Int) { progress = p }
        }
        web.setDownloadListener { u, ua, cd, mime, _ ->
            onDownload(AddPrefill(
                text = u, referer = web.url ?: "", cookie = CookieManager.getInstance().getCookie(u) ?: "",
                ua = ua ?: "", fileName = URLUtil.guessFileName(u, cd, mime),
            ))
        }
    }

    fun load(input: String) {
        val t = input.trim()
        val target = when {
            t.isEmpty() -> return
            t.startsWith("http://") || t.startsWith("https://") -> t
            t.contains(' ') || !t.contains('.') -> "https://www.google.com/search?q=" + java.net.URLEncoder.encode(t, "UTF-8")
            else -> "https://$t"
        }
        web.loadUrl(target)
    }

    fun download(hit: MediaHit) {
        onDownload(AddPrefill(
            text = hit.url, referer = web.url ?: "", cookie = CookieManager.getInstance().getCookie(hit.url) ?: "",
            ua = web.settings.userAgentString ?: "", fileName = hit.label,
        ))
    }

    fun destroy() { try { web.destroy() } catch (_: Throwable) { } }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BrowserScreen(state: BrowserState, home: String) {
    val p = LocalPal.current
    var field by remember { mutableStateOf(state.url.ifEmpty { home }) }
    var showMedia by remember { mutableStateOf(false) }
    if (state.url.isNotEmpty() && state.url != field && state.progress == 100) field = state.url

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.clickable { if (state.web.canGoBack()) state.web.goBack() }.padding(2.dp)) { Img3D("play", 30.dp, Modifier.rotate(180f)) }
                OutlinedTextField(
                    field, { field = it }, Modifier.weight(1f), singleLine = true,
                    placeholder = { Text("Search or enter address") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Go),
                    keyboardActions = KeyboardActions(onGo = { state.load(field) }),
                )
                Box(Modifier.clickable { state.load(field) }.padding(2.dp)) { Img3D("search", 34.dp) }
            }
            if (state.progress in 1..99) androidx.compose.material3.LinearProgressIndicator(progress = { state.progress / 100f }, modifier = Modifier.fillMaxWidth())
            AndroidView(factory = {
                (state.web.parent as? android.view.ViewGroup)?.removeView(state.web)
                if (state.web.url == null) state.load(home)
                state.web
            }, modifier = Modifier.weight(1f).fillMaxWidth())
        }
        if (state.media.isNotEmpty()) {
            Box(
                Modifier.align(Alignment.BottomEnd).padding(end = 16.dp, bottom = 100.dp).clip(RoundedCornerShape(50))
                    .background(p.accent).clickable { showMedia = true }.padding(horizontal = 16.dp, vertical = 12.dp),
            ) { Text("⬇ ${state.media.size} media found", color = androidx.compose.ui.graphics.Color.White, fontWeight = FontWeight.Bold) }
        }
    }
    if (showMedia) {
        ModalBottomSheet(onDismissRequest = { showMedia = false }, sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true), containerColor = p.card) {
            Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 32.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Media on this page", color = p.text, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                for (m in state.media.toList()) {
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(p.bg1.copy(alpha = 0.5f))
                            .clickable { showMedia = false; state.download(m) }.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        Img3D(if (m.label.matches(Regex("(?i).*\\.(mp3|m4a|aac|flac|ogg)$"))) "audio" else "video", 40.dp)
                        Column(Modifier.weight(1f)) {
                            Text(m.label, color = p.text, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(m.url, color = p.sub, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
        }
    }
}
