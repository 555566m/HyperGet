package com.hyperget.app

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.Image

data class Pal(
    val bg1: Color, val bg2: Color, val card: Color, val border: Color,
    val text: Color, val sub: Color, val accent: Color, val dark: Boolean,
)

val Accents = listOf(
    Color(0xFF3D8BFF), Color(0xFF8B5CFF), Color(0xFF22C55E),
    Color(0xFFFF8A1F), Color(0xFFFF4FA3), Color(0xFF14B8A6),
)

fun palette(dark: Boolean, accent: Color) = if (dark)
    Pal(Color(0xFF0A0C16), Color(0xFF171030), Color(0xFF1B1E30), Color(0xFF2A2E48), Color.White, Color(0xFF9AA2BE), accent, true)
else
    Pal(Color(0xFFF2F4FB), Color(0xFFE6E9F7), Color.White, Color(0xFFDADFF0), Color(0xFF12152B), Color(0xFF5B6382), accent, false)

val LocalPal = staticCompositionLocalOf { palette(true, Accents[0]) }

@Composable
fun HyperTheme(dark: Boolean, accent: Color, content: @Composable () -> Unit) {
    val pal = palette(dark, accent)
    val scheme = if (dark) darkColorScheme(
        primary = accent, background = pal.bg1, surface = pal.card, onSurface = pal.text,
        onBackground = pal.text, surfaceVariant = pal.card, onSurfaceVariant = pal.sub,
        surfaceContainerHigh = pal.card, surfaceContainerLow = pal.card, surfaceContainer = pal.card,
    ) else lightColorScheme(
        primary = accent, background = pal.bg1, surface = pal.card, onSurface = pal.text,
        onBackground = pal.text, surfaceVariant = pal.card, onSurfaceVariant = pal.sub,
        surfaceContainerHigh = pal.card, surfaceContainerLow = pal.card, surfaceContainer = pal.card,
    )
    CompositionLocalProvider(LocalPal provides pal) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}

@Composable
fun AppBackground(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    val p = LocalPal.current
    Box(modifier.fillMaxSize().background(Brush.verticalGradient(listOf(p.bg1, p.bg2, p.bg1)))) { content() }
}

fun icon(name: String): Int = when (name) {
    "download" -> R.drawable.ic3d_download; "pause" -> R.drawable.ic3d_pause; "play" -> R.drawable.ic3d_play
    "stop" -> R.drawable.ic3d_stop; "queue" -> R.drawable.ic3d_queue; "folder" -> R.drawable.ic3d_folder
    "browser" -> R.drawable.ic3d_browser; "torrent" -> R.drawable.ic3d_torrent; "scheduler" -> R.drawable.ic3d_scheduler
    "speed" -> R.drawable.ic3d_speed; "settings" -> R.drawable.ic3d_settings; "notify" -> R.drawable.ic3d_notify
    "theme" -> R.drawable.ic3d_theme; "link" -> R.drawable.ic3d_link; "trash" -> R.drawable.ic3d_trash
    "share" -> R.drawable.ic3d_share; "check" -> R.drawable.ic3d_check; "error" -> R.drawable.ic3d_error
    "search" -> R.drawable.ic3d_search; "add" -> R.drawable.ic3d_add; "stats" -> R.drawable.ic3d_stats
    "wifi" -> R.drawable.ic3d_wifi; "battery" -> R.drawable.ic3d_battery; "video" -> R.drawable.ic3d_video
    "audio" -> R.drawable.ic3d_audio; "image" -> R.drawable.ic3d_image; "archive" -> R.drawable.ic3d_archive
    "doc" -> R.drawable.ic3d_doc; "apk" -> R.drawable.ic3d_apk; "lock" -> R.drawable.ic3d_lock
    "bolt" -> R.drawable.ic3d_bolt
    else -> R.drawable.ic3d_file
}

@Composable
fun Img3D(name: String, size: Dp, modifier: Modifier = Modifier) {
    Image(painterResource(icon(name)), contentDescription = name, modifier = modifier.size(size))
}

/** Tile like the "Everything" grid: dark tinted gradient card, 3D icon, bold title, small subtitle. */
@Composable
fun Tile3D(title: String, subtitle: String, icon: String, tint: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val p = LocalPal.current
    val top = if (p.dark) tint.copy(alpha = 0.55f).compositeOver(Color(0xFF14121C)) else tint.copy(alpha = 0.30f).compositeOver(Color.White)
    val bottom = if (p.dark) tint.copy(alpha = 0.22f).compositeOver(Color(0xFF0E0D15)) else tint.copy(alpha = 0.12f).compositeOver(Color.White)
    Column(
        modifier.clip(RoundedCornerShape(26.dp))
            .background(Brush.linearGradient(listOf(top, bottom)))
            .border(1.dp, tint.copy(alpha = 0.35f), RoundedCornerShape(26.dp))
            .clickable(onClick = onClick).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        Img3D(icon, 62.dp)
        Box(Modifier.height(8.dp))
        Text(title, color = if (p.dark) Color.White else p.text, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
        Text(subtitle, color = if (p.dark) Color.White.copy(alpha = 0.72f) else p.sub, fontSize = 12.sp, lineHeight = 15.sp)
    }
}

private fun Color.compositeOver(bg: Color): Color {
    val a = alpha
    return Color(red * a + bg.red * (1 - a), green * a + bg.green * (1 - a), blue * a + bg.blue * (1 - a), 1f)
}

@Composable
fun Pill(text: String, selected: Boolean, onClick: () -> Unit) {
    val p = LocalPal.current
    val bg = if (selected) p.accent else p.card
    Box(
        Modifier.clip(RoundedCornerShape(50)).background(bg)
            .border(1.dp, if (selected) p.accent else p.border, RoundedCornerShape(50))
            .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = if (selected) Color.White else p.sub, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
    }
}

@Composable
fun GradientBar(progress: Float, modifier: Modifier = Modifier, height: Dp = 8.dp, color: Color = LocalPal.current.accent) {
    val p = LocalPal.current
    Canvas(modifier.fillMaxWidth().height(height)) {
        val r = CornerRadius(size.height / 2, size.height / 2)
        drawRoundRect(if (p.dark) Color(0xFF2A2E48) else Color(0xFFDDE1F2), size = size, cornerRadius = r)
        val w = size.width * progress.coerceIn(0f, 1f)
        if (w > 0f) drawRoundRect(
            Brush.horizontalGradient(listOf(color, color.copy(alpha = 0.65f).compositeOver(Color.White))),
            size = Size(maxOf(w, size.height), size.height), cornerRadius = r,
        )
    }
}

/** IDM-style map of which parts of the file are done. */
@Composable
fun SegmentMap(map: FloatArray, modifier: Modifier = Modifier) {
    val p = LocalPal.current
    Canvas(modifier.fillMaxWidth().height(14.dp)) {
        drawRoundRect(if (p.dark) Color(0xFF2A2E48) else Color(0xFFDDE1F2), size = size, cornerRadius = CornerRadius(6f, 6f))
        if (map.isEmpty()) return@Canvas
        val w = size.width / map.size
        for (i in map.indices) {
            if (map[i] > 0.01f) drawRect(p.accent.copy(alpha = 0.35f + 0.65f * map[i]), Offset(i * w, 0f), Size(w + 0.5f, size.height))
        }
    }
}

@Composable
fun Card(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable () -> Unit) {
    val p = LocalPal.current
    val m = modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(p.card)
        .border(1.dp, p.border, RoundedCornerShape(22.dp))
    Box(if (onClick != null) m.clickable(onClick = onClick) else m) { content() }
}
