package com.hyperget.core;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

/** Persists every download as a small properties file (written atomically). */
final class ItemStore {
    private final File dir;

    ItemStore(File dir) {
        this.dir = dir;
        dir.mkdirs();
    }

    synchronized void save(DownloadItem it) {
        Properties p = new Properties();
        put(p, "url", it.url); put(p, "finalUrl", it.finalUrl); put(p, "fileName", it.fileName);
        put(p, "dir", it.dir); put(p, "referer", it.referer); put(p, "cookie", it.cookie);
        put(p, "userAgent", it.userAgent); put(p, "authUser", it.authUser); put(p, "authPass", it.authPass);
        put(p, "mirrors", it.mirrors); put(p, "checksum", it.checksum); put(p, "mime", it.mime);
        put(p, "etag", it.etag); put(p, "lastModified", it.lastModified); put(p, "error", it.error);
        put(p, "category", it.category); put(p, "checksumResult", it.checksumResult);
        p.setProperty("total", String.valueOf(it.total));
        p.setProperty("done", String.valueOf(it.done));
        p.setProperty("createdAt", String.valueOf(it.createdAt));
        p.setProperty("completedAt", String.valueOf(it.completedAt));
        p.setProperty("failedAt", String.valueOf(it.failedAt));
        p.setProperty("order", String.valueOf(it.order));
        p.setProperty("threads", String.valueOf(it.threads));
        p.setProperty("speedLimit", String.valueOf(it.speedLimit));
        p.setProperty("autoRetries", String.valueOf(it.autoRetries));
        p.setProperty("resumable", String.valueOf(it.resumable));
        p.setProperty("status", it.status.name());
        for (Map.Entry<String, String> h : it.headers.entrySet()) p.setProperty("h." + h.getKey(), h.getValue());
        long[][] rem = it.remaining;
        if (rem != null) {
            StringBuilder sb = new StringBuilder();
            for (long[] r : rem) sb.append(r[0]).append('-').append(r[1]).append(';');
            p.setProperty("remaining", sb.toString());
        }
        File tmp = new File(dir, it.id + ".tmp");
        File dst = new File(dir, it.id + ".item");
        try (OutputStream os = new FileOutputStream(tmp)) {
            p.store(os, null);
            os.flush();
        } catch (IOException e) {
            return;
        }
        if (!tmp.renameTo(dst)) {
            dst.delete();
            tmp.renameTo(dst);
        }
    }

    synchronized void delete(String id) {
        new File(dir, id + ".item").delete();
        new File(dir, id + ".tmp").delete();
    }

    synchronized List<DownloadItem> loadAll() {
        List<DownloadItem> out = new ArrayList<>();
        File[] files = dir.listFiles((d, n) -> n.endsWith(".item"));
        if (files == null) return out;
        for (File f : files) {
            Properties p = new Properties();
            try (InputStream in = new FileInputStream(f)) {
                p.load(in);
            } catch (Exception e) {
                continue;
            }
            String id = f.getName().substring(0, f.getName().length() - 5);
            DownloadItem it = new DownloadItem(id);
            it.url = g(p, "url"); it.finalUrl = g(p, "finalUrl"); it.fileName = g(p, "fileName");
            it.dir = g(p, "dir"); it.referer = g(p, "referer"); it.cookie = g(p, "cookie");
            it.userAgent = g(p, "userAgent"); it.authUser = g(p, "authUser"); it.authPass = g(p, "authPass");
            it.mirrors = g(p, "mirrors"); it.checksum = g(p, "checksum"); it.mime = g(p, "mime");
            it.etag = g(p, "etag"); it.lastModified = g(p, "lastModified"); it.error = g(p, "error");
            it.category = g(p, "category"); it.checksumResult = g(p, "checksumResult");
            it.total = l(p, "total", -1); it.done = l(p, "done", 0); it.createdAt = l(p, "createdAt", 0);
            it.completedAt = l(p, "completedAt", 0); it.failedAt = l(p, "failedAt", 0); it.order = l(p, "order", 0);
            it.threads = (int) l(p, "threads", 0); it.speedLimit = (int) l(p, "speedLimit", 0);
            it.autoRetries = (int) l(p, "autoRetries", 0);
            it.resumable = Boolean.parseBoolean(p.getProperty("resumable", "false"));
            try { it.status = DownloadStatus.valueOf(p.getProperty("status", "PAUSED")); } catch (Exception e) { it.status = DownloadStatus.PAUSED; }
            for (String k : p.stringPropertyNames()) if (k.startsWith("h.")) it.headers.put(k.substring(2), p.getProperty(k));
            String rem = p.getProperty("remaining");
            if (rem != null) {
                List<long[]> l = new ArrayList<>();
                for (String s : rem.split(";")) {
                    int d = s.indexOf('-');
                    if (d > 0) {
                        try { l.add(new long[]{Long.parseLong(s.substring(0, d)), Long.parseLong(s.substring(d + 1))}); } catch (Exception ignored) { }
                    }
                }
                it.remaining = l.toArray(new long[0][]);
            }
            out.add(it);
        }
        out.sort((a, b) -> Long.compare(a.order, b.order));
        return out;
    }

    private static void put(Properties p, String k, String v) { p.setProperty(k, v == null ? "" : v); }
    private static String g(Properties p, String k) { return p.getProperty(k, ""); }
    private static long l(Properties p, String k, long d) {
        try { return Long.parseLong(p.getProperty(k, String.valueOf(d))); } catch (Exception e) { return d; }
    }
}
