package com.hyperget.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items as lazyItems
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hyperget.core.DownloadRequest
import com.hyperget.core.DownloadStatus
import java.io.File

enum class Filter(val label: String) { ALL("All"), ACTIVE("Active"), WAITING("Waiting"), DONE("Done"), FAILED("Failed") }

data class AddPrefill(
    val text: String = "", val referer: String = "", val cookie: String = "",
    val ua: String = "", val fileName: String = "",
)

object UrlUtil {
    private val re = Regex("(https?://[^\\s\"'<>]+)", RegexOption.IGNORE_CASE)
    fun extract(text: String): List<String> = re.findAll(text).map { it.value.trimEnd(',', ')', ']', '.') }.distinct().toList()
    fun looksLikeLink(text: String) = re.containsMatchIn(text) || text.startsWith("magnet:")
}

fun copyText(ctx: Context, label: String, text: String) {
    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText(label, text))
    Toast.makeText(ctx, "Copied", Toast.LENGTH_SHORT).show()
}

private fun matches(it: UiItem, f: Filter) = when (f) {
    Filter.ALL -> true
    Filter.ACTIVE -> it.status.isRunning
    Filter.WAITING -> it.status == DownloadStatus.QUEUED || it.status == DownloadStatus.PAUSED
    Filter.DONE -> it.status == DownloadStatus.COMPLETED
    Filter.FAILED -> it.status == DownloadStatus.FAILED
}

private fun catIcon(c: String) = when (c) {
    "video", "audio", "image", "archive", "apk", "doc", "torrent" -> c
    else -> "file"
}

@Composable
fun HomeScreen(app: HyperApp) {
    val p = LocalPal.current
    val items by app.items.collectAsState()
    val speed by app.speed.collectAsState()
    val online by app.online.collectAsState()
    var filter by remember { mutableStateOf(Filter.ALL) }
    var query by remember { mutableStateOf("") }
    var searching by remember { mutableStateOf(false) }
    var detailsId by remember { mutableStateOf<String?>(null) }
    val filtered = remember(items, filter, query) {
        items.filter { matches(it, filter) && (query.isBlank() || it.name.contains(query, true) || it.url.contains(query, true)) }
    }
    val sel = items.firstOrNull { it.id == detailsId }

    LazyColumn(
        Modifier.statusBarsPadding(),
        contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 130.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item { Hero(app, items, speed, online, onSearch = { searching = !searching; if (!searching) query = "" }) }
        if (searching) item {
            OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("Search downloads") })
        }
        item {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                for (f in Filter.values()) {
                    val n = items.count { matches(it, f) }
                    Pill(if (f == Filter.ALL) f.label else "${f.label} $n", filter == f) { filter = f }
                }
            }
        }
        if (filtered.isEmpty()) item {
            Column(Modifier.fillMaxWidth().padding(vertical = 48.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Img3D("download", 110.dp)
                Spacer(Modifier.height(12.dp))
                Text("No downloads here", color = p.text, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text("Tap + to paste a link, or open the Browser", color = p.sub, fontSize = 13.sp)
            }
        }
        lazyItems(filtered, key = { it.id }) { it ->
            DownloadRow(it, online, app.net.wifi, onClick = { detailsId = it.id }, onToggle = {
                val ctx = app
                when {
                    it.status.isRunning -> app.engine.pause(it.id)
                    it.status == DownloadStatus.COMPLETED -> Open.file(ctx, File(it.dir, it.name))
                    else -> app.engine.start(it.id, true)
                }
            })
        }
    }
    if (sel != null) DetailsSheet(app, sel) { detailsId = null }
}

@Composable
private fun Hero(app: HyperApp, items: List<UiItem>, speed: Double, online: Boolean, onSearch: () -> Unit) {
    val p = LocalPal.current
    var wifiOnly by remember { mutableStateOf(app.prefs.wifiOnly) }
    var threads by remember { mutableStateOf(app.prefs.threads) }
    var limit by remember { mutableStateOf(app.prefs.speedLimitKb) }
    val active = items.count { it.status.isRunning }
    val hist = app.history()
    val a = p.accent
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(30.dp))
            .background(Brush.linearGradient(listOf(a.copy(alpha = 0.95f), Color(0xFF2A0F3D), Color(0xFF14102A))))
            .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Img3D("bolt", 34.dp)
            Spacer(Modifier.width(8.dp))
            Text("HyperGet", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp, modifier = Modifier.weight(1f))
            Box(Modifier.clickable(onClick = onSearch).padding(4.dp)) { Img3D("search", 34.dp) }
        }
        Text(
            if (!online && active > 0) "Waiting for network…" else Fmt.speed(speed),
            color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 34.sp,
        )
        Canvas(Modifier.fillMaxWidth().height(40.dp)) {
            if (hist.size > 1) {
                val mx = (hist.maxOrNull() ?: 1f).coerceAtLeast(1f)
                val path = Path()
                hist.forEachIndexed { i, v ->
                    val x = size.width * i / (hist.size - 1)
                    val y = size.height - size.height * (v / mx) * 0.95f
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                drawPath(path, Color.White.copy(alpha = 0.85f), style = Stroke(width = 4f, cap = StrokeCap.Round))
            }
        }
        Text("$active active · ${items.count { it.status == DownloadStatus.QUEUED }} queued · ${items.count { it.status == DownloadStatus.COMPLETED }} done",
            color = Color.White.copy(alpha = 0.8f), fontSize = 13.sp)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            HeroChip(if (active > 0) "Pause all" else "Resume all", true) {
                if (active > 0) app.engine.pauseAll() else { app.engine.resumeAll(); app.startServiceSafe() }
            }
            HeroChip(if (wifiOnly) "Wi‑Fi only ✓" else "Wi‑Fi only", wifiOnly) {
                wifiOnly = !wifiOnly; app.prefs.wifiOnly = wifiOnly; app.applyPrefs()
            }
            HeroChip("Threads $threads", false) {
                threads = when (threads) { 4 -> 8; 8 -> 16; 16 -> 32; else -> 4 }
                app.prefs.threads = threads; app.applyPrefs()
            }
            HeroChip(if (limit == 0) "Limit ∞" else "Limit ${if (limit >= 1024) "${limit / 1024} MB" else "$limit KB"}/s", false) {
                limit = when (limit) { 0 -> 512; 512 -> 1024; 1024 -> 2048; 2048 -> 5120; 5120 -> 10240; else -> 0 }
                app.prefs.speedLimitKb = limit; app.applyPrefs()
            }
        }
    }
}

@Composable
private fun HeroChip(text: String, strong: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.clip(RoundedCornerShape(50))
            .background(if (strong) Color.White.copy(alpha = 0.95f) else Color.Black.copy(alpha = 0.28f))
            .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 8.dp),
    ) {
        Text(text, color = if (strong) Color(0xFF1A1030) else Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
    }
}

@Composable
private fun DownloadRow(it: UiItem, online: Boolean, wifi: Boolean, onClick: () -> Unit, onToggle: () -> Unit) {
    val p = LocalPal.current
    val prefs = HyperApp.instance.prefs
    val line = when (it.status) {
        DownloadStatus.DOWNLOADING -> "${Fmt.bytes(it.done)} / ${Fmt.bytes(it.total)} · ${Fmt.speed(it.speed)} · ${Fmt.eta(it.eta)} · ${it.activeThreads}×"
        DownloadStatus.WAITING_NETWORK -> if (prefs.wifiOnly && !wifi) "Waiting for Wi‑Fi…" else "Waiting for network… (${Fmt.bytes(it.done)})"
        DownloadStatus.CONNECTING -> "Connecting…"
        DownloadStatus.QUEUED -> "Queued"
        DownloadStatus.PAUSED -> "Paused · ${Fmt.bytes(it.done)}" + if (it.total > 0) " / ${Fmt.bytes(it.total)}" else ""
        DownloadStatus.VERIFYING -> "Finishing…"
        DownloadStatus.COMPLETED -> "Completed · ${Fmt.bytes(it.total)}"
        DownloadStatus.FAILED -> it.error.ifEmpty { "Failed" }
    }
    val lineColor = when (it.status) {
        DownloadStatus.FAILED -> Color(0xFFFF6B6B)
        DownloadStatus.COMPLETED -> Color(0xFF4ADE80)
        else -> p.sub
    }
    Card(onClick = onClick) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Img3D(if (it.status == DownloadStatus.FAILED) "error" else catIcon(it.category), 54.dp)
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(it.name, color = p.text, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (it.status != DownloadStatus.COMPLETED && it.status != DownloadStatus.FAILED)
                    GradientBar(it.progress, height = 7.dp)
                Text(line, color = lineColor, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            Box(Modifier.clickable(onClick = onToggle).padding(2.dp)) {
                Img3D(
                    when {
                        it.status.isRunning -> "pause"
                        it.status == DownloadStatus.COMPLETED -> "check"
                        else -> "play"
                    }, 44.dp,
                )
            }
        }
    }
}

// --------------------------------------------------------------------- details

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DetailsSheet(app: HyperApp, d: UiItem, onDismiss: () -> Unit) {
    val p = LocalPal.current
    val ctx = LocalContext.current
    val state = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var showDelete by remember { mutableStateOf(false) }
    var showRename by remember { mutableStateOf(false) }
    var showHash by remember { mutableStateOf(false) }
    val file = File(d.dir, d.name)

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = state, containerColor = p.card) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Img3D(catIcon(d.category), 56.dp)
                Column(Modifier.weight(1f)) {
                    Text(d.name, color = p.text, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text(d.status.name.lowercase().replace('_', ' ').replaceFirstChar { it.uppercase() }, color = p.accent, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }
                Text("${(d.progress * 100).toInt()}%", color = p.text, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
            }
            GradientBar(d.progress, height = 10.dp)
            if (d.status.isRunning || d.status == DownloadStatus.PAUSED) {
                Text("Download map", color = p.sub, fontSize = 12.sp)
                SegmentMap(d.segMap)
            }
            Info("Size", if (d.total > 0) "${Fmt.bytes(d.done)} of ${Fmt.bytes(d.total)}" else Fmt.bytes(d.done) + " (size unknown)")
            if (d.status == DownloadStatus.DOWNLOADING) {
                Info("Speed", Fmt.speed(d.speed)); Info("Time left", Fmt.eta(d.eta)); Info("Connections", "${d.activeThreads}")
            }
            Info("Resume support", if (d.resumable) "Yes (multi-connection)" else "No / unknown")
            if (d.error.isNotEmpty()) Info("Error", d.error)
            Info("Folder", d.dir)
            Info("Link", d.url)
            if (d.checksumResult.isNotEmpty()) Info("SHA", d.checksumResult)

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                if (d.status == DownloadStatus.COMPLETED) {
                    Act("folder", "Open") { Open.file(ctx, file) }
                    Act("share", "Share") { Open.share(ctx, file) }
                } else {
                    Act(if (d.status.isRunning) "pause" else "play", if (d.status.isRunning) "Pause" else "Start") {
                        if (d.status.isRunning) app.engine.pause(d.id) else app.engine.start(d.id, true)
                    }
                    Act("bolt", "Restart") { app.engine.restart(d.id) }
                }
                Act("link", "Copy link") { copyText(ctx, "link", d.url) }
                Act("doc", "Rename") { showRename = true }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                if (d.status == DownloadStatus.COMPLETED) Act("lock", "Checksum") { showHash = true } else Spacer(Modifier.width(64.dp))
                Act("trash", "Delete") { showDelete = true }
                Spacer(Modifier.width(64.dp)); Spacer(Modifier.width(64.dp))
            }
            if (d.status != DownloadStatus.COMPLETED) {
                var th by remember(d.id) { mutableStateOf(if (d.threads > 0) d.threads else app.prefs.threads) }
                Text("Connections: $th  (applies on next start)", color = p.sub, fontSize = 13.sp)
                Slider(th.toFloat(), { th = it.toInt(); app.engine.setThreads(d.id, th) }, valueRange = 1f..32f)
                Text("Speed limit for this download", color = p.sub, fontSize = 13.sp)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    for ((label, kb) in listOf("∞" to 0, "256 KB/s" to 256, "1 MB/s" to 1024, "3 MB/s" to 3072, "10 MB/s" to 10240)) {
                        Pill(label, d.speedLimitKb == kb) { app.engine.setSpeedLimit(d.id, kb * 1024) }
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
    if (showDelete) {
        var withFile by remember { mutableStateOf(true) }
        AlertDialog(
            onDismissRequest = { showDelete = false },
            title = { Text("Delete download?") },
            text = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(withFile, { withFile = it }); Text("Also delete the file from storage")
                }
            },
            confirmButton = { TextButton({ app.engine.remove(d.id, withFile); showDelete = false; onDismiss() }) { Text("Delete") } },
            dismissButton = { TextButton({ showDelete = false }) { Text("Cancel") } },
        )
    }
    if (showRename) {
        var name by remember { mutableStateOf(d.name) }
        AlertDialog(
            onDismissRequest = { showRename = false },
            title = { Text("Rename") },
            text = { OutlinedTextField(name, { name = it }, singleLine = true) },
            confirmButton = { TextButton({ app.engine.rename(d.id, name); showRename = false }) { Text("Save") } },
            dismissButton = { TextButton({ showRename = false }) { Text("Cancel") } },
        )
    }
    if (showHash) {
        var md5 by remember { mutableStateOf("calculating…") }
        var sha by remember { mutableStateOf("calculating…") }
        androidx.compose.runtime.LaunchedEffect(d.id) {
            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                try {
                    md5 = com.hyperget.core.Util.checksum(file, "MD5")
                    sha = com.hyperget.core.Util.checksum(file, "SHA-256")
                } catch (e: Exception) { md5 = "error"; sha = e.message ?: "error" }
            }
        }
        AlertDialog(
            onDismissRequest = { showHash = false },
            title = { Text("Checksum") },
            text = { Column { Text("MD5\n$md5\n\nSHA-256\n$sha", fontSize = 12.sp) } },
            confirmButton = { TextButton({ copyText(ctx, "sha256", sha) }) { Text("Copy SHA-256") } },
            dismissButton = { TextButton({ showHash = false }) { Text("Close") } },
        )
    }
}

@Composable
private fun Info(k: String, v: String) {
    val p = LocalPal.current
    Row(verticalAlignment = Alignment.Top) {
        Text(k, color = p.sub, fontSize = 13.sp, modifier = Modifier.width(110.dp))
        Text(v, color = p.text, fontSize = 13.sp, modifier = Modifier.weight(1f), maxLines = 3, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun Act(icon: String, label: String, onClick: () -> Unit) {
    val p = LocalPal.current
    Column(Modifier.width(64.dp).clip(RoundedCornerShape(16.dp)).clickable(onClick = onClick).padding(4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Img3D(icon, 44.dp)
        Text(label, color = p.sub, fontSize = 11.sp, maxLines = 1)
    }
}

// ------------------------------------------------------------------- add sheet

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddDownloadSheet(app: HyperApp, pre: AddPrefill, onDismiss: () -> Unit) {
    val p = LocalPal.current
    val ctx = LocalContext.current
    val state = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var text by remember { mutableStateOf(pre.text) }
    var fileName by remember { mutableStateOf(pre.fileName) }
    var dir by remember { mutableStateOf(app.prefs.dir()) }
    var threads by remember { mutableStateOf(app.prefs.threads.toFloat()) }
    var limitKb by remember { mutableStateOf("") }
    var more by remember { mutableStateOf(false) }
    var referer by remember { mutableStateOf(pre.referer) }
    var cookie by remember { mutableStateOf(pre.cookie) }
    var ua by remember { mutableStateOf(pre.ua) }
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var hash by remember { mutableStateOf("") }
    var startNow by remember { mutableStateOf(true) }
    val urls = remember(text) { UrlUtil.extract(text) }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = state, containerColor = p.card) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Img3D("download", 44.dp)
                Text("Add download", color = p.text, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
            }
            OutlinedTextField(text, { text = it }, Modifier.fillMaxWidth(), minLines = 3, maxLines = 6,
                label = { Text("Link(s) — one per line") })
            if (urls.size > 1) Text("${urls.size} links found", color = p.accent, fontSize = 12.sp)
            if (urls.size <= 1) OutlinedTextField(fileName, { fileName = it }, Modifier.fillMaxWidth(), singleLine = true,
                label = { Text("File name (optional)") })
            OutlinedTextField(dir, { dir = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Save to folder") })
            Text("Connections: ${threads.toInt()}", color = p.sub, fontSize = 13.sp)
            Slider(threads, { threads = it }, valueRange = 1f..32f)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Start immediately", color = p.text, modifier = Modifier.weight(1f)); Switch(startNow, { startNow = it })
            }
            Row(Modifier.clickable { more = !more }.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(if (more) "▼ Advanced" else "▶ Advanced (speed limit, headers, login, checksum)", color = p.accent, fontWeight = FontWeight.SemiBold)
            }
            if (more) {
                OutlinedTextField(limitKb, { limitKb = it.filter { c -> c.isDigit() } }, Modifier.fillMaxWidth(), singleLine = true,
                    label = { Text("Speed limit KB/s (0 = unlimited)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                OutlinedTextField(referer, { referer = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Referer") })
                OutlinedTextField(cookie, { cookie = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Cookie") })
                OutlinedTextField(ua, { ua = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("User-Agent") })
                OutlinedTextField(user, { user = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Username") })
                OutlinedTextField(pass, { pass = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Password") })
                OutlinedTextField(hash, { hash = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Checksum (sha256:… / md5:…)") })
            }
            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                TextButton(onDismiss, Modifier.weight(1f)) { Text("Cancel") }
                androidx.compose.material3.Button({
                    if (urls.isEmpty()) {
                        Toast.makeText(ctx, "No http/https link found", Toast.LENGTH_SHORT).show()
                    } else {
                        for (u in urls) {
                            val r = DownloadRequest(u)
                            if (urls.size == 1) r.fileName = fileName
                            r.dir = dir; r.threads = threads.toInt(); r.startNow = startNow
                            r.referer = referer; r.cookie = cookie; r.userAgent = ua
                            r.authUser = user; r.authPass = pass; r.checksum = hash.trim()
                            r.speedLimit = (limitKb.toIntOrNull() ?: 0) * 1024
                            app.engine.add(r)
                        }
                        Toast.makeText(ctx, "${urls.size} download(s) added", Toast.LENGTH_SHORT).show()
                        onDismiss()
                    }
                }, Modifier.weight(1f)) { Text("Download") }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}
