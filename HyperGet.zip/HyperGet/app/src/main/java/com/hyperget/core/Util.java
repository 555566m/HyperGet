package com.hyperget.core;

import java.io.File;
import java.io.IOException;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class Util {
    private Util() {}

    private static final Pattern CD_STAR = Pattern.compile("filename\\*\\s*=\\s*([^']*)'[^']*'([^;]+)", Pattern.CASE_INSENSITIVE);
    private static final Pattern CD_PLAIN = Pattern.compile("filename\\s*=\\s*(\"([^\"]*)\"|[^;]+)", Pattern.CASE_INSENSITIVE);

    /** Percent-encode characters that HttpURLConnection would choke on (spaces, non-ASCII...). */
    public static String normalizeUrl(String u) {
        u = u.trim();
        StringBuilder sb = new StringBuilder(u.length() + 16);
        byte[] bytes = u.getBytes(StandardCharsets.UTF_8);
        for (byte b : bytes) {
            int c = b & 0xff;
            if (c <= 0x20 || c >= 0x7f || "\"<>\\^`{|}".indexOf(c) >= 0) {
                sb.append('%').append(String.format("%02X", c));
            } else {
                sb.append((char) c);
            }
        }
        return sb.toString();
    }

    public static String fileNameFromDisposition(String cd) {
        if (cd == null) return null;
        Matcher m = CD_STAR.matcher(cd);
        if (m.find()) {
            try {
                String cs = m.group(1).isEmpty() ? "UTF-8" : m.group(1);
                return URLDecoder.decode(m.group(2).trim().replace("+", "%2B"), cs);
            } catch (Exception ignored) { }
        }
        m = CD_PLAIN.matcher(cd);
        if (m.find()) {
            String v = m.group(2) != null ? m.group(2) : m.group(1).trim();
            return v;
        }
        return null;
    }

    public static String fileNameFromUrl(String url) {
        try {
            String p = new java.net.URL(url).getPath();
            int i = p.lastIndexOf('/');
            String n = i >= 0 ? p.substring(i + 1) : p;
            return URLDecoder.decode(n.replace("+", "%2B"), "UTF-8");
        } catch (Exception e) {
            return "";
        }
    }

    public static String sanitize(String n) {
        if (n == null) n = "";
        n = n.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]", "_").trim();
        while (n.startsWith(".")) n = n.substring(1);
        while (n.endsWith(".") || n.endsWith(" ")) n = n.substring(0, n.length() - 1);
        if (n.getBytes(StandardCharsets.UTF_8).length > 200) {
            String ext = "";
            int dot = n.lastIndexOf('.');
            if (dot > 0 && n.length() - dot <= 10) ext = n.substring(dot);
            String base = dot > 0 ? n.substring(0, dot) : n;
            while ((base + ext).getBytes(StandardCharsets.UTF_8).length > 200) base = base.substring(0, base.length() - 1);
            n = base + ext;
        }
        return n.isEmpty() ? "download" : n;
    }

    public static String extensionForMime(String mime) {
        if (mime == null) return "";
        mime = mime.toLowerCase(Locale.ROOT);
        int s = mime.indexOf(';');
        if (s >= 0) mime = mime.substring(0, s).trim();
        switch (mime) {
            case "video/mp4": return ".mp4";
            case "video/x-matroska": return ".mkv";
            case "video/webm": return ".webm";
            case "audio/mpeg": return ".mp3";
            case "audio/mp4": return ".m4a";
            case "audio/ogg": return ".ogg";
            case "image/jpeg": return ".jpg";
            case "image/png": return ".png";
            case "image/gif": return ".gif";
            case "image/webp": return ".webp";
            case "application/pdf": return ".pdf";
            case "application/zip": return ".zip";
            case "application/vnd.android.package-archive": return ".apk";
            case "application/x-bittorrent": return ".torrent";
            case "application/x-7z-compressed": return ".7z";
            case "application/x-rar-compressed": return ".rar";
            default: return "";
        }
    }

    public static String categoryFor(String name, String mime) {
        String n = name == null ? "" : name.toLowerCase(Locale.ROOT);
        String m = mime == null ? "" : mime.toLowerCase(Locale.ROOT);
        if (n.matches(".*\\.(mp4|mkv|avi|mov|wmv|flv|webm|3gp|m4v|ts)$") || m.startsWith("video/")) return "video";
        if (n.matches(".*\\.(mp3|m4a|aac|flac|wav|ogg|opus|wma)$") || m.startsWith("audio/")) return "audio";
        if (n.matches(".*\\.(jpg|jpeg|png|gif|webp|bmp|svg|heic)$") || m.startsWith("image/")) return "image";
        if (n.matches(".*\\.(zip|rar|7z|tar|gz|xz|bz2|tgz|iso)$")) return "archive";
        if (n.matches(".*\\.(apk|apks|xapk|aab)$")) return "apk";
        if (n.matches(".*\\.(pdf|doc|docx|xls|xlsx|ppt|pptx|txt|epub|csv)$")) return "doc";
        if (n.endsWith(".torrent")) return "torrent";
        return "other";
    }

    /** name.ext -> name (1).ext until neither the file nor its .part exists. */
    public static String uniqueName(File dir, String name) {
        File f = new File(dir, name);
        if (!f.exists() && !new File(dir, name + ".part").exists()) return name;
        int dot = name.lastIndexOf('.');
        String base = dot > 0 ? name.substring(0, dot) : name;
        String ext = dot > 0 ? name.substring(dot) : "";
        for (int i = 1; i < 10000; i++) {
            String cand = base + " (" + i + ")" + ext;
            if (!new File(dir, cand).exists() && !new File(dir, cand + ".part").exists()) return cand;
        }
        return base + "_" + System.currentTimeMillis() + ext;
    }

    public static String checksum(File f, String algo) throws IOException {
        try (java.io.InputStream in = new java.io.FileInputStream(f)) {
            java.security.MessageDigest md = java.security.MessageDigest.getInstance(algo);
            byte[] b = new byte[256 * 1024];
            int n;
            while ((n = in.read(b)) > 0) md.update(b, 0, n);
            StringBuilder sb = new StringBuilder();
            for (byte x : md.digest()) sb.append(String.format("%02x", x));
            return sb.toString();
        } catch (java.security.NoSuchAlgorithmException e) {
            throw new IOException(e);
        }
    }
}
