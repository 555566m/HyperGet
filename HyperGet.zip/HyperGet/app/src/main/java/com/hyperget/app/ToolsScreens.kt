package com.hyperget.app

import android.app.TimePickerDialog
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hyperget.core.DownloadStatus

private class ToolTile(val title: String, val sub: String, val icon: String, val tint: Color, val action: () -> Unit)

enum class Screen { HOME, BROWSER, TOOLS, SETTINGS, SCHEDULER, STATS }

@Composable
private fun Header(title: String, sub: String) {
    val p = LocalPal.current
    Column(Modifier.padding(top = 8.dp, bottom = 6.dp)) {
        Text(title, color = p.text, fontWeight = FontWeight.ExtraBold, fontSize = 30.sp)
        Text(sub, color = p.sub, fontSize = 14.sp)
    }
}

@Composable
fun ToolsScreen(
    app: HyperApp, go: (Screen) -> Unit, onPaste: () -> Unit, onExport: () -> Unit, onImport: () -> Unit, onTheme: () -> Unit,
) {
    val p = LocalPal.current
    val ctx = LocalContext.current
    var showTheme by remember { mutableStateOf(false) }
    var showBackup by remember { mutableStateOf(false) }
    var showClear by remember { mutableStateOf(false) }

    Column(Modifier.statusBarsPadding().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 130.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Header("Tools", "Everything HyperGet can do")
        Text("Everything", color = p.text, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        val tiles = listOf(
            ToolTile("Browser", "Grab files & videos from any site", "browser", Color(0xFF14B8A6)) { go(Screen.BROWSER) },
            ToolTile("Scheduler", "Start & stop at set times", "scheduler", Color(0xFF8B5CFF)) { go(Screen.SCHEDULER) },
            ToolTile("Statistics", "Speed graph and totals", "stats", Color(0xFFE0457B)) { go(Screen.STATS) },
            ToolTile("Paste link", "Add from clipboard", "link", Color(0xFF3D8BFF)) { onPaste() },
            ToolTile("Speed & connections", "Threads, limits, retries", "speed", Color(0xFF84CC16)) { go(Screen.SETTINGS) },
            ToolTile("Storage", "Folder & all-files access", "folder", Color(0xFFFF8A1F)) { go(Screen.SETTINGS) },
            ToolTile("Theme", "Dark, light, accent", "theme", Color(0xFFD946EF)) { showTheme = true },
            ToolTile("Backup", "Export / import list", "archive", Color(0xFFF59E0B)) { showBackup = true },
            ToolTile("Battery", "Keep downloads alive", "battery", Color(0xFF22C55E)) {
                try {
                    val pm = ctx.getSystemService(PowerManager::class.java)
                    if (pm.isIgnoringBatteryOptimizations(ctx.packageName)) Toast.makeText(ctx, "Already unrestricted", Toast.LENGTH_SHORT).show()
                    else ctx.startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + ctx.packageName)))
                } catch (_: Throwable) {
                    try { ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } catch (_: Throwable) { }
                }
            },
            ToolTile("Notifications", "Sound & vibration", "notify", Color(0xFFEAB308)) {
                try {
                    ctx.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName))
                } catch (_: Throwable) { }
            },
            ToolTile("Proxy & security", "Proxy, SSL, user-agent", "lock", Color(0xFFF97316)) { go(Screen.SETTINGS) },
            ToolTile("Clean up", "Remove finished downloads", "trash", Color(0xFFEF4444)) { showClear = true },
        )
        for (row in tiles.chunked(2)) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                for (t in row) Tile3D(t.title, t.sub, t.icon, t.tint, Modifier.weight(1f), onClick = t.action)
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }

    if (showTheme) {
        var mode by remember { mutableStateOf(app.prefs.theme) }
        var acc by remember { mutableStateOf(app.prefs.accent) }
        AlertDialog(
            onDismissRequest = { showTheme = false },
            title = { Text("Theme") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        for ((i, n) in listOf("System", "Dark", "Light").withIndex()) Pill(n, mode == i) { mode = i; app.prefs.theme = i; onTheme() }
                    }
                    Text("Accent colour", fontSize = 13.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        for ((i, c) in Accents.withIndex()) {
                            Box(Modifier.size(if (acc == i) 38.dp else 30.dp).clip(CircleShape).background(c).clickable { acc = i; app.prefs.accent = i; onTheme() })
                        }
                    }
                }
            },
            confirmButton = { TextButton({ showTheme = false }) { Text("Done") } },
        )
    }
    if (showBackup) AlertDialog(
        onDismissRequest = { showBackup = false },
        title = { Text("Backup download list") },
        text = { Text("Export all download links to a .txt file, or import links from one (one link per line).") },
        confirmButton = { TextButton({ showBackup = false; onExport() }) { Text("Export") } },
        dismissButton = { TextButton({ showBackup = false; onImport() }) { Text("Import") } },
    )
    if (showClear) {
        AlertDialog(
            onDismissRequest = { showClear = false },
            title = { Text("Clear finished downloads?") },
            text = { Text("Only the list entries are removed. Files stay in your storage.") },
            confirmButton = { TextButton({ app.engine.clearFinished(false); showClear = false }) { Text("Clear") } },
            dismissButton = { TextButton({ showClear = false }) { Text("Cancel") } },
        )
    }
}

// -------------------------------------------------------------------- settings

@Composable
private fun SwitchRow(title: String, sub: String, value: Boolean, onChange: (Boolean) -> Unit) {
    val p = LocalPal.current
    var v by remember { mutableStateOf(value) }
    Row(Modifier.fillMaxWidth().clickable { v = !v; onChange(v) }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = p.text, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            if (sub.isNotEmpty()) Text(sub, color = p.sub, fontSize = 12.sp)
        }
        Switch(v, { v = it; onChange(it) })
    }
}

@Composable
private fun SliderRow(title: String, value: Int, range: IntRange, label: (Int) -> String, onChange: (Int) -> Unit) {
    val p = LocalPal.current
    var v by remember { mutableStateOf(value.toFloat()) }
    Column(Modifier.padding(vertical = 6.dp)) {
        Row {
            Text(title, color = p.text, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, modifier = Modifier.weight(1f))
            Text(label(v.toInt()), color = p.accent, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
        Slider(v, { v = it }, valueRange = range.first.toFloat()..range.last.toFloat(), onValueChangeFinished = { onChange(v.toInt()) })
    }
}

@Composable
private fun TextRow(title: String, value: String, numeric: Boolean = false, hint: String = "", onSave: (String) -> Unit) {
    val p = LocalPal.current
    var cur by remember { mutableStateOf(value) }
    var edit by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth().clickable { edit = true }.padding(vertical = 8.dp)) {
        Text(title, color = p.text, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
        Text(cur.ifEmpty { hint.ifEmpty { "Not set" } }, color = p.sub, fontSize = 12.sp)
    }
    if (edit) {
        var tmp by remember { mutableStateOf(cur) }
        AlertDialog(
            onDismissRequest = { edit = false },
            title = { Text(title) },
            text = {
                OutlinedTextField(tmp, { tmp = if (numeric) it.filter { c -> c.isDigit() } else it }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = if (numeric) KeyboardType.Number else KeyboardType.Text))
            },
            confirmButton = { TextButton({ cur = tmp.trim(); onSave(cur); edit = false }) { Text("Save") } },
            dismissButton = { TextButton({ edit = false }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun Section(title: String, content: @Composable () -> Unit) {
    val p = LocalPal.current
    Text(title, color = p.accent, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
    Card { Column(Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) { content() } }
}

@Composable
fun SettingsScreen(app: HyperApp) {
    val ctx = LocalContext.current
    val pr = app.prefs
    fun commit() = app.applyPrefs()
    Column(Modifier.statusBarsPadding().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 130.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Header("Settings", "Tune speed, reliability and storage")
        Section("Speed") {
            SliderRow("Connections per download", pr.threads, 1..32, { "$it" }) { pr.threads = it; commit() }
            SliderRow("Simultaneous downloads", pr.maxConcurrent, 1..10, { "$it" }) { pr.maxConcurrent = it; commit() }
            TextRow("Global speed limit (KB/s, 0 = unlimited)", pr.speedLimitKb.toString(), numeric = true) { pr.speedLimitKb = it.toIntOrNull() ?: 0; commit() }
        }
        Section("Reliability") {
            SwitchRow("Auto-retry failed downloads", "Keeps trying again in the background", pr.autoRetry) { pr.autoRetry = it; commit() }
            SliderRow("Give up after no progress", pr.giveUpMin, 0..120, { if (it == 0) "never" else "$it min" }) { pr.giveUpMin = it; commit() }
            SwitchRow("Wi‑Fi only", "Wait for Wi‑Fi instead of using mobile data", pr.wifiOnly) { pr.wifiOnly = it; commit() }
            SliderRow("Pause when battery below", pr.minBattery, 0..50, { if (it == 0) "off" else "$it%" }) { pr.minBattery = it; commit() }
            SwitchRow("Pre-allocate file", "Reserve space first; turn off if big files hang on SD card", pr.preallocate) { pr.preallocate = it; commit() }
            SwitchRow("Overwrite existing files", "Off = add (1), (2)… to the name", pr.overwrite) { pr.overwrite = it; commit() }
        }
        Section("Storage") {
            TextRow("Download folder", pr.dir()) { pr.downloadDir = it; commit() }
            val has = Storage.hasAllFiles()
            Text(if (has) "All-files access: granted" else "All-files access: not granted (files go to the app folder)",
                color = LocalPal.current.sub, fontSize = 12.sp, modifier = Modifier.padding(bottom = 4.dp))
            if (!has && Build.VERSION.SDK_INT >= 30) TextButton({
                try {
                    ctx.startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + ctx.packageName)))
                } catch (_: Throwable) { ctx.startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)) }
            }) { Text("Grant all-files access") }
        }
        Section("Network") {
            TextRow("Proxy host", pr.proxyHost, hint = "none") { pr.proxyHost = it; commit() }
            TextRow("Proxy port", if (pr.proxyPort == 0) "" else pr.proxyPort.toString(), numeric = true, hint = "none") { pr.proxyPort = it.toIntOrNull() ?: 0; commit() }
            TextRow("User-Agent", pr.userAgent, hint = "default (Chrome mobile)") { pr.userAgent = it; commit() }
            SwitchRow("Ignore SSL certificate errors", "Only for servers you trust", pr.insecureSsl) { pr.insecureSsl = it; commit() }
        }
        Section("General") {
            SwitchRow("Watch clipboard", "Offer to download copied links", pr.clipboardWatch) { pr.clipboardWatch = it }
            TextRow("Browser home page", pr.homePage) { pr.homePage = it }
        }
        Text("HyperGet 1.0", color = LocalPal.current.sub, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
    }
}

// ------------------------------------------------------------------- scheduler

@Composable
fun SchedulerScreen(app: HyperApp) {
    val p = LocalPal.current
    val ctx = LocalContext.current
    val pr = app.prefs
    var enabled by remember { mutableStateOf(pr.schedEnabled) }
    var start by remember { mutableStateOf(pr.schedStart) }
    var stop by remember { mutableStateOf(pr.schedStop) }
    fun save() {
        pr.schedEnabled = enabled; pr.schedStart = start; pr.schedStop = stop
        Scheduler.apply(ctx)
        if (enabled) { if (Scheduler.insideWindow(pr)) { app.engine.resumeAll(); app.startServiceSafe() } else app.engine.pauseAll() }
        else app.engine.resumeAll()
    }
    fun pick(cur: Int, set: (Int) -> Unit) {
        TimePickerDialog(ctx, { _, h, m -> set(h * 60 + m); save() }, cur / 60, cur % 60, true).show()
    }
    Column(Modifier.statusBarsPadding().padding(horizontal = 16.dp).padding(bottom = 130.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Header("Scheduler", "Download only during a time window")
        Tile3D("Window", if (enabled) "Active daily ${Fmt.clock(start)} – ${Fmt.clock(stop)}" else "Off — downloads run any time", "scheduler", Color(0xFF8B5CFF), Modifier.fillMaxWidth()) { }
        Card {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                SwitchRow("Enable scheduler", "Pauses outside the window, resumes inside", enabled) { enabled = it; save() }
                Row(Modifier.fillMaxWidth().clickable { pick(start) { start = it } }, verticalAlignment = Alignment.CenterVertically) {
                    Text("Start time", color = p.text, modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                    Text(Fmt.clock(start), color = p.accent, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                }
                Row(Modifier.fillMaxWidth().clickable { pick(stop) { stop = it } }, verticalAlignment = Alignment.CenterVertically) {
                    Text("Stop time", color = p.text, modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                    Text(Fmt.clock(stop), color = p.accent, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                }
            }
        }
        Text("Tip: allow Battery → Unrestricted (Tools → Battery) so Android never delays the alarms.", color = p.sub, fontSize = 12.sp)
    }
}

// ------------------------------------------------------------------------ stats

@Composable
fun StatsScreen(app: HyperApp) {
    val p = LocalPal.current
    val items by app.items.collectAsState()
    val speed by app.speed.collectAsState()
    val hist = app.history()
    val done = items.filter { it.status == DownloadStatus.COMPLETED }
    val doneBytes = done.sumOf { it.total.coerceAtLeast(0) }
    val failed = items.count { it.status == DownloadStatus.FAILED }
    Column(Modifier.statusBarsPadding().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 130.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Header("Statistics", "Live speed and totals")
        Card {
            Column(Modifier.padding(16.dp)) {
                Text("Speed now", color = p.sub, fontSize = 12.sp)
                Text(Fmt.speed(speed), color = p.text, fontWeight = FontWeight.ExtraBold, fontSize = 30.sp)
                val a = p.accent
                Canvas(Modifier.fillMaxWidth().height(120.dp).padding(top = 8.dp)) {
                    if (hist.size > 1) {
                        val mx = (hist.maxOrNull() ?: 1f).coerceAtLeast(1f)
                        val path = Path()
                        hist.forEachIndexed { i, v ->
                            val x = size.width * i / (hist.size - 1)
                            val y = size.height - size.height * (v / mx) * 0.95f
                            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                        }
                        drawPath(path, a, style = Stroke(width = 5f, cap = StrokeCap.Round))
                    }
                }
                Text("Peak ${Fmt.speed((hist.maxOrNull() ?: 0f).toDouble())}", color = p.sub, fontSize = 12.sp)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Tile3D("${done.size}", "Completed (${Fmt.bytes(doneBytes)})", "check", Color(0xFF22C55E), Modifier.weight(1f)) { }
            Tile3D("$failed", "Failed", "error", Color(0xFFEF4444), Modifier.weight(1f)) { }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Tile3D("${items.count { it.status.isRunning }}", "Active now", "download", Color(0xFF3D8BFF), Modifier.weight(1f)) { }
            Tile3D("${items.size}", "Total in list", "queue", Color(0xFF8B5CFF), Modifier.weight(1f)) { }
        }
    }
}
