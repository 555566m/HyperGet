package com.hyperget.core;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/** One download. Fields are volatile; the UI reads them, the engine writes them. */
public final class DownloadItem {
    public final String id;
    public volatile String url = "", finalUrl = "", fileName = "", dir = "", referer = "", cookie = "",
            userAgent = "", authUser = "", authPass = "", mirrors = "", checksum = "", mime = "",
            etag = "", lastModified = "", error = "", category = "other", checksumResult = "";
    public final Map<String, String> headers = new ConcurrentHashMap<>();
    public volatile long total = -1, done = 0, createdAt = 0, completedAt = 0, failedAt = 0, order = 0;
    public volatile int threads = 0, speedLimit = 0, autoRetries = 0, activeThreads = 0;
    public volatile boolean resumable = false;
    public volatile DownloadStatus status = DownloadStatus.QUEUED;
    public volatile double speed = 0;
    public volatile long etaSec = -1;
    /** Unfinished byte ranges {pos,end}; null = nothing downloaded yet (fresh start). */
    public volatile long[][] remaining = null;

    public DownloadItem(String id) {
        this.id = id;
    }

    public float progress() {
        if (status == DownloadStatus.COMPLETED) return 1f;
        if (total <= 0) return 0f;
        return Math.min(1f, (float) ((double) done / total));
    }

    /** Fraction (0..1) of each of {@code buckets} equal slices of the file that is already downloaded. */
    public float[] segmentMap(int buckets) {
        float[] m = new float[buckets];
        long t = total;
        if (t <= 0) return m;
        if (status == DownloadStatus.COMPLETED) {
            java.util.Arrays.fill(m, 1f);
            return m;
        }
        java.util.Arrays.fill(m, remaining == null ? 0f : 1f);
        long[][] rem = remaining;
        if (rem == null) return m;
        double bs = (double) t / buckets;
        for (long[] r : rem) {
            for (int b = (int) Math.min(buckets - 1, r[0] / bs); b < buckets; b++) {
                double bStart = b * bs, bEnd = bStart + bs;
                if (bStart > r[1]) break;
                double ov = Math.min(bEnd, r[1] + 1.0) - Math.max(bStart, (double) r[0]);
                if (ov > 0) m[b] = Math.max(0f, m[b] - (float) (ov / bs));
            }
        }
        return m;
    }
}
