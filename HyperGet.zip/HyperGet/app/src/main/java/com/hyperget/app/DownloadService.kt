package com.hyperget.app

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.hyperget.core.DownloadStatus

/** Keeps the process, CPU and Wi-Fi awake while downloads run, shows live progress. */
class DownloadService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private var wake: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private var idleTicks = 0
    private var started = false

    private val tick = object : Runnable {
        override fun run() {
            val app = HyperApp.instance
            if (!app.engine.hasActive()) {
                if (++idleTicks >= 4) { shutdownService(); return }
            } else idleTicks = 0
            notifyNow()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val app = HyperApp.instance
        when (intent?.action) {
            ACTION_PAUSE_ALL -> app.engine.pauseAll()
            ACTION_RESUME_ALL -> app.engine.resumeAll()
            ACTION_EXIT -> { app.engine.pauseAll(); shutdownService(); return START_NOT_STICKY }
        }
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIF_ID, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
            } else startForeground(NOTIF_ID, buildNotification())
        } catch (_: Throwable) { stopSelf(); return START_NOT_STICKY }
        acquireLocks()
        if (!started) { started = true; handler.postDelayed(tick, 1000) }
        return START_STICKY
    }

    private fun acquireLocks() {
        if (wake == null) {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "hyperget:dl").apply { setReferenceCounted(false); acquire(12 * 60 * 60 * 1000L) }
        }
        if (wifiLock == null) {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            @Suppress("DEPRECATION")
            wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "hyperget:wifi").apply { setReferenceCounted(false); acquire() }
        }
    }

    private fun shutdownService() {
        handler.removeCallbacks(tick)
        started = false
        try { wake?.release() } catch (_: Throwable) { }
        try { wifiLock?.release() } catch (_: Throwable) { }
        wake = null; wifiLock = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        try { wake?.release() } catch (_: Throwable) { }
        try { wifiLock?.release() } catch (_: Throwable) { }
        super.onDestroy()
    }

    private fun notifyNow() {
        try {
            getSystemService(android.app.NotificationManager::class.java).notify(NOTIF_ID, buildNotification())
        } catch (_: Throwable) { }
    }

    private fun act(action: String, code: Int) = PendingIntent.getService(
        this, code, Intent(this, DownloadService::class.java).setAction(action),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    private fun buildNotification(): Notification {
        val app = HyperApp.instance
        val items = app.items.value
        val running = items.filter { it.status.isRunning }
        val waiting = items.count { it.status == DownloadStatus.QUEUED }
        val speed = running.sumOf { if (it.status == DownloadStatus.DOWNLOADING) it.speed else 0.0 }
        val totalDone = running.sumOf { it.done }
        val total = running.sumOf { if (it.total > 0) it.total else 0L }
        val offline = !app.online.value
        val title = when {
            app.engine.isPausedAll() -> "Paused"
            offline && running.isNotEmpty() -> "Waiting for network…"
            running.isEmpty() -> "HyperGet"
            else -> "${running.size} downloading · ${Fmt.speed(speed)}"
        }
        val text = when {
            running.size == 1 -> running[0].name
            running.isNotEmpty() -> "${Fmt.bytes(totalDone)} / ${Fmt.bytes(total)}" + if (waiting > 0) " · $waiting queued" else ""
            waiting > 0 -> "$waiting queued"
            else -> "Idle"
        }
        val b = NotificationCompat.Builder(this, HyperApp.CH_PROGRESS)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(title).setContentText(text)
            .setOngoing(true).setOnlyAlertOnce(true).setSilent(true)
            .setContentIntent(PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
        if (total > 0) b.setProgress(1000, (totalDone * 1000.0 / total).toInt().coerceIn(0, 1000), false)
        else if (running.isNotEmpty()) b.setProgress(0, 0, true)
        if (app.engine.isPausedAll()) b.addAction(0, "Resume all", act(ACTION_RESUME_ALL, 2))
        else b.addAction(0, "Pause all", act(ACTION_PAUSE_ALL, 1))
        b.addAction(0, "Exit", act(ACTION_EXIT, 3))
        return b.build()
    }

    companion object {
        const val NOTIF_ID = 1
        const val ACTION_PAUSE_ALL = "com.hyperget.PAUSE_ALL"
        const val ACTION_RESUME_ALL = "com.hyperget.RESUME_ALL"
        const val ACTION_EXIT = "com.hyperget.EXIT"
    }
}
