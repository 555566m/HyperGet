package com.hyperget.core;

public enum ConflictPolicy { RENAME, OVERWRITE }
