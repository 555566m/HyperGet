package com.hyperget.core;

import java.io.IOException;

final class Errors {
    private Errors() {}

    /** Server answered with an HTTP error status. */
    static final class HttpStatusException extends IOException {
        final int code;
        final long retryAfterMs;

        HttpStatusException(int code, long retryAfterMs) {
            super("HTTP " + code);
            this.code = code;
            this.retryAfterMs = retryAfterMs;
        }
    }

    /** Local write problem (disk full, no permission...). Never retried. */
    static final class DiskException extends IOException {
        DiskException(IOException cause) {
            super(cause.getMessage() == null ? "Disk write error" : cause.getMessage(), cause);
        }
    }

    /** Unrecoverable for this attempt. If {@code restart} the next start begins from byte 0. */
    static final class FatalException extends RuntimeException {
        final boolean restart;

        FatalException(String msg, boolean restart) {
            super(msg);
            this.restart = restart;
        }
    }
}
