package com.hyperget.core;

/** A byte range [start..end] being fetched. {@code pos} is the next byte to write. Only one worker writes pos. */
final class Segment {
    final long start;
    volatile long end;   // inclusive; may shrink when the segment is split
    volatile long pos;

    Segment(long start, long end, long pos) {
        this.start = start;
        this.end = end;
        this.pos = pos;
    }

    long remaining() {
        return Math.max(0, end - pos + 1);
    }

    boolean unbounded() {
        return end == Long.MAX_VALUE;
    }
}
