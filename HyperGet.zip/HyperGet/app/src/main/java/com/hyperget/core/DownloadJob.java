package com.hyperget.core;

import com.hyperget.core.Errors.DiskException;
import com.hyperget.core.Errors.FatalException;
import com.hyperget.core.Errors.HttpStatusException;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.net.HttpURLConnection;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Runs one download: probe -> segment -> N worker connections -> dynamic re-splitting -> finalize.
 *
 * Reliability rules:
 *  - workers never give up on transient errors; they back off and retry (resuming from the exact byte)
 *  - while the device is offline nothing is counted as a failure; workers just wait
 *  - a segment hitting 401/403/404/410 triggers a re-resolve of the original link (fresh redirect/token)
 *  - repeated failures with many connections lower the connection count, later it is raised again
 *  - the job only fails after "no progress for giveUpAfterMs" or on fatal errors (disk full, file changed)
 *  - unfinished ranges are checkpointed to disk every 2 s so crashes/kill/reboot resume to the byte
 */
final class DownloadJob implements Runnable {
    enum Kind { COMPLETED, PAUSED, FAILED }

    static final class Result {
        final Kind kind;
        final String message;
        final boolean restart;

        Result(Kind kind, String message, boolean restart) {
            this.kind = kind;
            this.message = message;
            this.restart = restart;
        }
    }

    private static final int BUF = 128 * 1024;
    private static final Pattern CR_START = Pattern.compile("bytes\\s+(\\d+)-");

    private final DownloadEngine eng;
    private final DownloadItem item;
    private final Config cfg;
    private final Object lock = new Object();
    private final Object sleeper = new Object();
    private final ArrayDeque<Segment> pending = new ArrayDeque<>();
    private final ArrayList<Segment> active = new ArrayList<>();
    private final AtomicLong bytesDone = new AtomicLong();
    private final AtomicInteger alive = new AtomicInteger();
    private final AtomicInteger parallelism = new AtomicInteger(1);
    private final AtomicLong failureStamp = new AtomicLong(0);
    private final RateLimiter limiter = new RateLimiter();
    private final Set<HttpURLConnection> conns = ConcurrentHashMap.newKeySet();
    private final CountDownLatch finished = new CountDownLatch(1);

    private volatile boolean stopRequested;
    private volatile FatalException fatal;
    private volatile long lastProgressNs = System.nanoTime();
    private volatile String lastError = "";
    private volatile String curUrl;
    private volatile Http.Response streamResp;
    private final Object resolveLock = new Object();
    private long lastResolveNs = 0;
    private int resolveCount = 0;

    private File partFile, finalFile;
    private boolean ranged;
    private long total;
    private int desired;

    DownloadJob(DownloadEngine eng, DownloadItem item, Config cfg) {
        this.eng = eng;
        this.item = item;
        this.cfg = cfg;
    }

    void requestStop() {
        stopRequested = true;
        synchronized (sleeper) { sleeper.notifyAll(); }
        for (HttpURLConnection c : conns) {
            try { c.disconnect(); } catch (Throwable ignored) { }
        }
    }

    boolean awaitFinished(long ms) {
        try { return finished.await(ms, TimeUnit.MILLISECONDS); } catch (InterruptedException e) { return false; }
    }

    private boolean stopped() {
        return stopRequested || fatal != null;
    }

    private void sleepMs(long ms) {
        if (ms <= 0) return;
        synchronized (sleeper) {
            if (stopped()) return;
            try { sleeper.wait(ms); } catch (InterruptedException ignored) { }
        }
    }

    // ------------------------------------------------------------------ main

    @Override
    public void run() {
        Result res;
        try {
            res = execute();
        } catch (FatalException e) {
            res = new Result(Kind.FAILED, e.getMessage(), e.restart);
        } catch (Throwable t) {
            res = new Result(Kind.FAILED, String.valueOf(t), false);
        }
        for (HttpURLConnection c : conns) {
            try { c.disconnect(); } catch (Throwable ignored) { }
        }
        Http.Response sr = streamResp;
        if (sr != null) sr.close();
        finished.countDown();
        eng.onJobEnded(item, res);
    }

    private Result execute() throws Exception {
        item.status = DownloadStatus.CONNECTING;
        item.error = "";
        desired = Math.max(1, Math.min(cfg.maxThreads, item.threads > 0 ? item.threads : cfg.defaultThreads));

        Prober.Result p = probeWithRetry();
        if (p == null) return new Result(Kind.PAUSED, "", false);
        curUrl = p.finalUrl;
        streamResp = p.stream;

        File dir = new File(item.dir.isEmpty() ? cfg.defaultDir : item.dir);
        if (!dir.exists() && !dir.mkdirs() && !dir.exists()) {
            throw new FatalException("Cannot create folder: " + dir, false);
        }
        if (!dir.canWrite()) throw new FatalException("Folder is not writable: " + dir, false);
        item.dir = dir.getAbsolutePath();

        if (item.fileName.isEmpty()) {
            String n = Util.sanitize(p.fileName);
            if (n.equals("download") || n.isEmpty() || !n.contains(".")) {
                String ext = Util.extensionForMime(p.mime);
                if (!ext.isEmpty() && !n.toLowerCase().endsWith(ext)) n = (n.isEmpty() ? "download" : n) + ext;
            }
            item.fileName = n;
        }

        boolean fresh = item.remaining == null;
        File existingPart = new File(dir, item.fileName + ".part");
        if (!fresh) {
            boolean changed = (item.total > 0 && p.total > 0 && item.total != p.total)
                    || (!item.etag.isEmpty() && !p.etag.isEmpty() && !item.etag.equals(p.etag))
                    || !p.resumable || !existingPart.exists();
            if (changed) {
                fresh = true;
                item.remaining = null;
                existingPart.delete();
            }
        }

        total = p.total;
        ranged = p.resumable && total > 0;
        if (fresh) {
            if (cfg.conflict == ConflictPolicy.RENAME) item.fileName = Util.uniqueName(dir, item.fileName);
            else new File(dir, item.fileName).delete();
            new File(dir, item.fileName + ".part").delete();
            item.done = 0;
            item.category = Util.categoryFor(item.fileName, p.mime);
        }
        item.total = total;
        item.resumable = ranged;
        item.etag = p.etag;
        item.lastModified = p.lastModified;
        item.mime = p.mime;
        item.finalUrl = p.finalUrl;
        partFile = new File(dir, item.fileName + ".part");
        finalFile = new File(dir, item.fileName);

        if (total == 0) {              // empty file
            partFile.createNewFile();
            return finish();
        }

        if (fresh || !ranged) {
            pending.clear();
            if (ranged) {
                int n = (int) Math.max(1, Math.min(desired, total / Math.max(1, cfg.minSplitBytes)));
                long chunk = total / n;
                for (int i = 0; i < n; i++) {
                    long s = i * chunk, e = i == n - 1 ? total - 1 : s + chunk - 1;
                    pending.add(new Segment(s, e, s));
                }
            } else {
                pending.add(new Segment(0, total > 0 ? total - 1 : Long.MAX_VALUE, 0));
            }
            bytesDone.set(0);
        } else {
            long rem = 0;
            for (long[] r : item.remaining) {
                if (r[0] <= r[1]) {
                    pending.add(new Segment(r[0], r[1], r[0]));
                    rem += r[1] - r[0] + 1;
                }
            }
            bytesDone.set(total - rem);
            if (pending.isEmpty()) return finish();
        }

        if (total > 0) {
            long need = (fresh ? total : total - bytesDone.get()) + (8L << 20);
            long usable = dir.getUsableSpace();
            if (usable > 0 && usable < need) {
                throw new FatalException("Not enough storage space (need " + (need >> 20) + " MB)", false);
            }
        }
        try (RandomAccessFile raf = new RandomAccessFile(partFile, "rw")) {
            if (cfg.preallocate && ranged && raf.length() != total) {
                try { raf.setLength(total); } catch (IOException ignored) { }
            }
        } catch (IOException e) {
            throw new FatalException("Cannot create file: " + e.getMessage(), false);
        }

        return runWorkers();
    }

    private Prober.Result probeWithRetry() {
        int attempt = 0;
        long started = System.nanoTime();
        while (!stopped()) {
            if (!awaitNetwork()) return null;
            started = Math.max(started, offlineSince());
            if (cfg.giveUpAfterMs > 0 && attempt > 0
                    && System.nanoTime() - started > cfg.giveUpAfterMs * 1_000_000L) {
                throw new FatalException("Cannot connect: " + (lastError.isEmpty() ? "timeout" : lastError), false);
            }
            try {
                return Prober.probe(item, cfg, item.url);
            } catch (HttpStatusException e) {
                lastError = "HTTP " + e.code;
                if (e.code == 401 || e.code == 407) throw new FatalException("Login required (HTTP " + e.code + ")", false);
                if (e.code == 403 || e.code == 404 || e.code == 410 || e.code == 451) {
                    if (++attempt > 3) throw new FatalException("Link not available (HTTP " + e.code + ")", false);
                } else if (e.code >= 400 && e.code < 500 && e.code != 408 && e.code != 429) {
                    throw new FatalException("Server refused (HTTP " + e.code + ")", false);
                } else if (++attempt > 25) {
                    throw new FatalException("Server error (HTTP " + e.code + ")", false);
                }
                sleepMs(Math.max(e.retryAfterMs, backoff(attempt)));
            } catch (IOException e) {
                lastError = String.valueOf(e.getMessage());
                if (eng.isOnline() && ++attempt > 12) throw new FatalException("Connection failed: " + lastError, false);
                sleepMs(backoff(Math.max(1, attempt)));
            }
        }
        return null;
    }

    // ------------------------------------------------------- controller loop

    private Result runWorkers() throws Exception {
        parallelism.set(ranged ? desired : 1);
        long lastTick = System.nanoTime(), lastDone = bytesDone.get(), lastCk = lastTick, lastSync = lastTick, lastRaise = lastTick;
        lastProgressNs = lastTick;
        item.status = DownloadStatus.DOWNLOADING;
        while (true) {
            maybeSpawn();
            sleepMs(200);
            long now = System.nanoTime();
            if (fatal != null || stopRequested) break;
            boolean allDone;
            synchronized (lock) { allDone = pending.isEmpty() && active.isEmpty(); }
            if (allDone && alive.get() == 0) break;

            if (now - lastTick >= 500_000_000L) {
                double dt = (now - lastTick) / 1e9;
                long d = bytesDone.get();
                double inst = (d - lastDone) / dt;
                item.speed = item.speed == 0 ? inst : item.speed * 0.7 + inst * 0.3;
                if (d != lastDone) lastProgressNs = now;
                lastDone = d;
                lastTick = now;
                item.done = d;
                item.etaSec = total > 0 && item.speed > 1 ? (long) ((total - d) / item.speed) : -1;
                item.activeThreads = alive.get();
                boolean online = eng.isOnline();
                item.status = online ? DownloadStatus.DOWNLOADING : DownloadStatus.WAITING_NETWORK;
                if (!online) lastProgressNs = now;
                if (cfg.giveUpAfterMs > 0 && now - lastProgressNs > cfg.giveUpAfterMs * 1_000_000L) {
                    String why = lastError.isEmpty() ? "no data received" : lastError;
                    fatal = new FatalException("No progress for " + (cfg.giveUpAfterMs / 60000) + " min: " + why, false);
                    break;
                }
                // stable for a while -> win back connections that were parked
                if (ranged && parallelism.get() < desired && now - lastRaise > 30_000_000_000L
                        && now - failureStamp.get() > 30_000_000_000L) {
                    parallelism.incrementAndGet();
                    lastRaise = now;
                }
            }
            if (now - lastCk >= 2_000_000_000L) {
                checkpoint(now - lastSync >= 30_000_000_000L);
                if (now - lastSync >= 30_000_000_000L) lastSync = now;
                lastCk = now;
            }
        }

        // stop everything and wait for workers
        boolean wasDone;
        synchronized (lock) { wasDone = pending.isEmpty() && active.isEmpty(); }
        stopRequested = stopRequested || fatal != null;
        if (!wasDone || fatal != null) requestStop();
        long deadline = System.nanoTime() + 15_000_000_000L;
        while (alive.get() > 0 && System.nanoTime() < deadline) sleepForce(50);
        item.done = bytesDone.get();
        item.speed = 0;
        item.etaSec = -1;
        item.activeThreads = 0;

        if (fatal != null) {
            checkpoint(true);
            return new Result(Kind.FAILED, fatal.getMessage(), fatal.restart);
        }
        if (!wasDone) {
            checkpoint(true);
            return new Result(Kind.PAUSED, "", false);
        }
        return finish();
    }

    private long offlineSince() {
        return eng.isOnline() ? 0 : System.nanoTime();
    }

    private void sleepForce(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException ignored) { }
    }

    private void maybeSpawn() {
        while (!stopped()) {
            synchronized (lock) {
                if (alive.get() >= parallelism.get()) return;
                if (pending.isEmpty() && !canSplit()) return;
                alive.incrementAndGet();
            }
            final int id = alive.get();
            Thread t = new Thread(() -> worker(), "hg-worker-" + item.id.substring(0, 4) + "-" + id);
            t.setDaemon(true);
            t.start();
        }
    }

    private boolean canSplit() {
        if (!ranged) return false;
        for (Segment a : active) if (a.end - a.pos + 1 >= 2 * cfg.minSplitBytes) return true;
        return false;
    }

    private Segment takeSegment() {
        synchronized (lock) {
            Segment s = pending.poll();
            if (s == null && ranged) {
                Segment victim = null;
                long best = 0;
                for (Segment a : active) {
                    long rem = a.end - a.pos + 1;
                    if (rem > best) { best = rem; victim = a; }
                }
                if (victim != null && best >= 2 * cfg.minSplitBytes) {
                    long mid = victim.pos + best / 2;
                    s = new Segment(mid, victim.end, mid);
                    victim.end = mid - 1;
                }
            }
            if (s != null) active.add(s);
            return s;
        }
    }

    private void checkpoint(boolean sync) {
        if (!ranged) { item.remaining = null; return; }
        ArrayList<long[]> rem = new ArrayList<>();
        synchronized (lock) {
            for (Segment s : pending) if (s.pos <= s.end) rem.add(new long[]{s.pos, s.end});
            for (Segment s : active) if (s.pos <= s.end) rem.add(new long[]{s.pos, s.end});
        }
        item.remaining = rem.toArray(new long[0][]);
        item.done = bytesDone.get();
        if (sync) {
            try (RandomAccessFile raf = new RandomAccessFile(partFile, "rw")) {
                raf.getFD().sync();
            } catch (IOException ignored) { }
        }
        eng.persist(item);
    }

    // ---------------------------------------------------------------- worker

    private void worker() {
        try {
            while (!stopped()) {
                Segment seg = takeSegment();
                if (seg == null) break;
                try (RandomAccessFile raf = new RandomAccessFile(partFile, "rw")) {
                    if (!downloadSegment(seg, raf)) break;
                }
            }
        } catch (FatalException e) {
            if (fatal == null) fatal = e;
        } catch (Throwable t) {
            if (fatal == null) fatal = new FatalException(t.toString(), false);
        } finally {
            alive.decrementAndGet();
        }
    }

    /** @return true if the segment is complete, false if the worker should exit (stopped / parked). */
    private boolean downloadSegment(Segment seg, RandomAccessFile raf) throws IOException {
        byte[] buf = new byte[BUF];
        int fails = 0;
        while (!stopped()) {
            if (seg.pos > seg.end) { segmentDone(seg); return true; }
            if (!awaitNetwork()) return false;
            long before = seg.pos;
            Http.Response r = null;
            try {
                boolean useStream = false;
                if (!ranged) {
                    Http.Response sr = streamResp;
                    streamResp = null;
                    if (sr != null) { r = sr; useStream = true; }
                    seg.pos = 0;
                    bytesDone.set(0);
                    item.done = 0;
                }
                if (!useStream) {
                    r = ranged
                            ? Http.get(cfg, item, curUrl, seg.pos, seg.end, !item.etag.isEmpty() ? item.etag : item.lastModified)
                            : Http.get(cfg, item, curUrl, -1, -1, null);
                }
                conns.add(r.conn);
                if (stopped()) return false;
                int code = r.code;
                if (code >= 400) throw new HttpStatusException(code, Http.retryAfterMs(r.conn));
                if (ranged) {
                    if (code == 206) {
                        Matcher m = CR_START.matcher(String.valueOf(r.conn.getHeaderField("Content-Range")));
                        if (m.find() && Long.parseLong(m.group(1)) != seg.pos) {
                            throw new IOException("Server returned wrong range");
                        }
                    } else if (code == 200) {
                        throw new FatalException("File changed on server (restarting)", true);
                    } else {
                        throw new HttpStatusException(code, 0);
                    }
                } else if (code != 200 && code != 206) {
                    throw new HttpStatusException(code, 0);
                }
                InputStream in = r.conn.getInputStream();
                while (!stopped()) {
                    long lim = seg.end;
                    if (seg.pos > lim) break;
                    int want = (int) Math.min(buf.length, lim - seg.pos + 1);
                    int n = in.read(buf, 0, want);
                    if (n < 0) break;
                    if (n == 0) continue;
                    int w = (int) Math.max(0, Math.min(n, seg.end - seg.pos + 1));
                    if (w > 0) {
                        try {
                            raf.seek(seg.pos);
                            raf.write(buf, 0, w);
                        } catch (IOException e) {
                            throw new DiskException(e);
                        }
                        seg.pos += w;
                        bytesDone.addAndGet(w);
                    }
                    throttle(n);
                    if (w < n) break;
                }
                if (stopped()) return false;
                if (seg.pos <= seg.end) {
                    if (seg.unbounded()) {            // unknown length stream ended normally
                        long len = seg.pos;
                        seg.end = len - 1;
                        total = len;
                        item.total = len;
                    } else {
                        throw new IOException("Connection closed early");
                    }
                }
                segmentDone(seg);
                return true;
            } catch (FatalException e) {
                throw e;
            } catch (DiskException e) {
                throw new FatalException("Storage error: " + e.getMessage(), false);
            } catch (HttpStatusException e) {
                if (stopped()) return false;
                lastError = "HTTP " + e.code;
                int c = e.code;
                if (c == 416) {
                    if (ranged && seg.pos >= total) { seg.end = seg.pos - 1; segmentDone(seg); return true; }
                    throw new FatalException("Server rejected range (HTTP 416), restarting", true);
                } else if (c == 401 || c == 403 || c == 404 || c == 410 || c == 451 || c == 407) {
                    if (!reResolve()) throw new FatalException("Link expired or blocked (HTTP " + c + ")", false);
                    fails++;
                } else if (c >= 400 && c < 500 && c != 408 && c != 429) {
                    throw new FatalException("Server refused (HTTP " + c + ")", false);
                } else {
                    fails++;
                    failureStamp.set(System.nanoTime());
                }
                if (seg.pos != before) fails = 0;
                if (maybePark(seg, fails)) return false;
                sleepMs(Math.max(e.retryAfterMs, backoff(fails)));
            } catch (IOException e) {
                if (stopped()) return false;
                lastError = String.valueOf(e.getMessage());
                if (eng.isOnline()) {
                    fails++;
                    failureStamp.set(System.nanoTime());
                }
                if (seg.pos != before) fails = 1;
                if (maybePark(seg, fails)) return false;
                sleepMs(backoff(fails));
            } finally {
                if (r != null) {
                    conns.remove(r.conn);
                    r.close();
                }
            }
        }
        return false;
    }

    /** After repeated failures with several connections: give this one up, let the others finish. */
    private boolean maybePark(Segment seg, int fails) {
        if (fails < 4 || !ranged || stopped()) return false;
        synchronized (lock) {
            if (parallelism.get() <= 1) return false;
            parallelism.decrementAndGet();
            active.remove(seg);
            pending.addFirst(seg);
        }
        return true;
    }

    private void segmentDone(Segment seg) {
        synchronized (lock) { active.remove(seg); }
    }

    private void throttle(int n) {
        long w1 = eng.globalLimiter.reserve(n, cfg.globalSpeedLimit);
        long w2 = limiter.reserve(n, item.speedLimit);
        long w = Math.max(w1, w2);
        if (w > 1_000_000L) sleepMs(w / 1_000_000L);
    }

    private boolean awaitNetwork() {
        while (!stopped()) {
            if (eng.isOnline()) return true;
            sleepMs(500);
        }
        return false;
    }

    private static long backoff(int fails) {
        long base = Math.min(30_000L, 1000L << Math.min(5, Math.max(0, fails - 1)));
        return base + (long) (Math.random() * base * 0.25);
    }

    private boolean reResolve() {
        synchronized (resolveLock) {
            long now = System.nanoTime();
            if (now - lastResolveNs < 5_000_000_000L && lastResolveNs != 0) return true;
            if (resolveCount >= 4) return false;
            resolveCount++;
            ArrayList<String> urls = new ArrayList<>();
            urls.add(item.url);
            for (String m : item.mirrors.split("\\s+")) if (!m.isEmpty()) urls.add(m);
            for (String u : urls) {
                try {
                    Prober.Result pr = Prober.probe(item, cfg, u);
                    if (pr.stream != null) pr.stream.close();
                    if (total > 0 && pr.total > 0 && pr.total != total) continue;
                    curUrl = pr.finalUrl;
                    item.finalUrl = pr.finalUrl;
                    lastResolveNs = now;
                    return true;
                } catch (IOException ignored) { }
            }
            return false;
        }
    }

    // -------------------------------------------------------------- finalize

    private Result finish() throws IOException {
        item.status = DownloadStatus.VERIFYING;
        try (RandomAccessFile raf = new RandomAccessFile(partFile, "rw")) {
            if (total > 0 && raf.length() != total) raf.setLength(total);
            raf.getFD().sync();
        }
        if (finalFile.exists() && !finalFile.delete()) {
            throw new FatalException("Cannot replace existing file", false);
        }
        if (!partFile.renameTo(finalFile)) {
            java.nio.file.Files.copy(partFile.toPath(), finalFile.toPath(),
                    java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            partFile.delete();
        }
        item.done = total > 0 ? total : finalFile.length();
        item.total = item.done;
        item.remaining = null;
        if (!item.checksum.isEmpty()) {
            String[] parts = item.checksum.split(":", 2);
            if (parts.length == 2) {
                String algo = parts[0].toUpperCase().replace("SHA", "SHA-").replace("SHA--", "SHA-");
                if (algo.equals("MD5") || algo.startsWith("SHA-")) {
                    String got = Util.checksum(finalFile, algo);
                    item.checksumResult = got;
                    if (!got.equalsIgnoreCase(parts[1].trim())) {
                        return new Result(Kind.FAILED, "Checksum mismatch", false);
                    }
                }
            }
        }
        return new Result(Kind.COMPLETED, "", false);
    }
}
