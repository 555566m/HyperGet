package com.hyperget.core;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/** Queue + scheduler for all downloads. Thread-safe. */
public final class DownloadEngine {
    public interface Listener {
        /** Structure or state changed (added/removed/finished/paused...). */
        void onListChanged();
        /** Once per second while anything runs: progress/speed values were refreshed. */
        void onTick();
        void onItemFinished(DownloadItem item);
    }

    public final Config config;
    final RateLimiter globalLimiter = new RateLimiter();
    private final ItemStore store;
    private final CopyOnWriteArrayList<DownloadItem> items = new CopyOnWriteArrayList<>();
    private final Map<String, DownloadJob> jobs = new ConcurrentHashMap<>();
    private final ScheduledExecutorService ticker = Executors.newSingleThreadScheduledExecutor(r -> {
        Thread t = new Thread(r, "hg-ticker");
        t.setDaemon(true);
        return t;
    });
    private final Object sched = new Object();
    private volatile Listener listener;
    private volatile boolean online = true;
    private volatile boolean paused;      // "pause all" master switch
    private volatile boolean shutdown;
    private long orderCounter;
    private long lastPersist;

    public DownloadEngine(File storeDir, Config config, Listener listener) {
        this.config = config;
        this.listener = listener;
        this.store = new ItemStore(storeDir);
        for (DownloadItem it : store.loadAll()) {
            orderCounter = Math.max(orderCounter, it.order);
            if (it.status.isRunning() || it.status == DownloadStatus.QUEUED) {
                it.status = config.resumeOnStart ? DownloadStatus.QUEUED : DownloadStatus.PAUSED;
            }
            if (it.status == DownloadStatus.FAILED && it.remaining == null && it.done > 0) it.done = 0;
            items.add(it);
        }
        ticker.scheduleWithFixedDelay(this::tick, 1, 1, TimeUnit.SECONDS);
        schedule();
    }

    public void setListener(Listener l) { this.listener = l; }

    public List<DownloadItem> items() { return new ArrayList<>(items); }

    public DownloadItem find(String id) {
        for (DownloadItem i : items) if (i.id.equals(id)) return i;
        return null;
    }

    public boolean isOnline() { return online; }

    /** Called by the platform layer (Wi-Fi only rule, airplane mode, ...). Downloads wait and auto-continue. */
    public void setOnline(boolean on) { this.online = on; }

    public boolean isPausedAll() { return paused; }

    public boolean hasActive() {
        for (DownloadItem i : items) if (i.status.isRunning() || (i.status == DownloadStatus.QUEUED && !paused)) return true;
        return false;
    }

    public DownloadItem add(DownloadRequest r) {
        DownloadItem it = new DownloadItem(UUID.randomUUID().toString().replace("-", "").substring(0, 12));
        it.url = r.url.trim();
        it.fileName = r.fileName == null ? "" : Util.sanitize(r.fileName.isEmpty() ? "" : r.fileName);
        if (r.fileName == null || r.fileName.isEmpty()) it.fileName = "";
        it.dir = r.dir == null ? "" : r.dir;
        it.referer = r.referer; it.cookie = r.cookie; it.userAgent = r.userAgent;
        it.authUser = r.authUser; it.authPass = r.authPass; it.mirrors = r.mirrors; it.checksum = r.checksum;
        it.headers.putAll(r.headers);
        it.threads = r.threads; it.speedLimit = r.speedLimit;
        it.createdAt = System.currentTimeMillis();
        synchronized (sched) { it.order = ++orderCounter; }
        it.status = r.startNow ? DownloadStatus.QUEUED : DownloadStatus.PAUSED;
        it.category = Util.categoryFor(it.fileName.isEmpty() ? Util.fileNameFromUrl(it.url) : it.fileName, "");
        items.add(it);
        store.save(it);
        fireList();
        schedule();
        return it;
    }

    /** Start / resume / retry. {@code force} ignores the simultaneous-download limit. */
    public void start(String id, boolean force) {
        DownloadItem it = find(id);
        if (it == null || it.status == DownloadStatus.COMPLETED || jobs.containsKey(id)) return;
        it.error = "";
        it.status = DownloadStatus.QUEUED;
        store.save(it);
        fireList();
        if (force) startJob(it); else schedule();
    }

    public void pause(String id) {
        DownloadItem it = find(id);
        if (it == null) return;
        DownloadJob j = jobs.get(id);
        if (j != null) {
            j.requestStop();
        } else if (it.status == DownloadStatus.QUEUED || it.status == DownloadStatus.FAILED) {
            it.status = DownloadStatus.PAUSED;
            store.save(it);
            fireList();
        }
    }

    public void pauseAll() {
        paused = true;
        for (DownloadItem i : items) pause(i.id);
    }

    public void resumeAll() {
        paused = false;
        for (DownloadItem i : items) {
            if (i.status == DownloadStatus.PAUSED || i.status == DownloadStatus.FAILED) {
                i.error = "";
                i.status = DownloadStatus.QUEUED;
                store.save(i);
            }
        }
        fireList();
        schedule();
    }

    /** Discard progress and download again from byte 0. */
    public void restart(String id) {
        DownloadItem it = find(id);
        if (it == null) return;
        DownloadJob j = jobs.get(id);
        if (j != null) { j.requestStop(); j.awaitFinished(5000); }
        deleteFiles(it, true);
        it.remaining = null; it.done = 0; it.fileName = (it.status == DownloadStatus.COMPLETED) ? it.fileName : it.fileName;
        it.status = DownloadStatus.QUEUED; it.error = ""; it.autoRetries = 0;
        store.save(it);
        fireList();
        schedule();
    }

    public void remove(final String id, final boolean deleteFile) {
        final DownloadItem it = find(id);
        if (it == null) return;
        items.remove(it);
        store.delete(id);
        fireList();
        Thread t = new Thread(() -> {
            DownloadJob j = jobs.get(id);
            if (j != null) { j.requestStop(); j.awaitFinished(8000); store.delete(id); }
            deleteFiles(it, deleteFile);
            schedule();
        }, "hg-remove");
        t.setDaemon(true);
        t.start();
    }

    public void clearFinished(boolean deleteFiles) {
        for (DownloadItem i : items) if (i.status == DownloadStatus.COMPLETED) remove(i.id, deleteFiles);
    }

    public void setThreads(String id, int n) { DownloadItem i = find(id); if (i != null) { i.threads = n; store.save(i); } }
    public void setSpeedLimit(String id, int bps) { DownloadItem i = find(id); if (i != null) { i.speedLimit = bps; store.save(i); } }

    public void rename(String id, String newName) {
        DownloadItem it = find(id);
        if (it == null || newName == null || newName.trim().isEmpty()) return;
        String n = Util.sanitize(newName);
        if (it.status == DownloadStatus.COMPLETED) {
            File f = new File(it.dir, it.fileName), t = new File(it.dir, n);
            if (f.exists() && !t.exists() && f.renameTo(t)) it.fileName = n;
        } else if (!jobs.containsKey(id)) {
            File p = new File(it.dir, it.fileName + ".part"), t = new File(it.dir, n + ".part");
            if (!p.exists() || (!t.exists() && p.renameTo(t))) it.fileName = n;
        }
        store.save(it);
        fireList();
    }

    public void shutdown() {
        shutdown = true;
        for (DownloadJob j : jobs.values()) j.requestStop();
        for (DownloadJob j : jobs.values()) j.awaitFinished(4000);
        ticker.shutdownNow();
    }

    // -------------------------------------------------------------- internal

    void persist(DownloadItem it) { store.save(it); }

    private void fireList() {
        Listener l = listener;
        if (l != null) l.onListChanged();
    }

    private void schedule() {
        if (shutdown) return;
        synchronized (sched) {
            if (paused) return;
            int running = jobs.size();
            for (DownloadItem it : items) {
                if (running >= config.maxConcurrent) break;
                if (it.status == DownloadStatus.QUEUED && !jobs.containsKey(it.id)) {
                    startJob(it);
                    running++;
                }
            }
        }
    }

    private void startJob(DownloadItem it) {
        synchronized (sched) {
            if (jobs.containsKey(it.id)) return;
            DownloadJob job = new DownloadJob(this, it, config);
            jobs.put(it.id, job);
            it.status = DownloadStatus.CONNECTING;
            Thread t = new Thread(job, "hg-job-" + it.id.substring(0, 4));
            t.setDaemon(true);
            t.start();
        }
        fireList();
    }

    void onJobEnded(DownloadItem it, DownloadJob.Result r) {
        jobs.remove(it.id);
        it.speed = 0;
        it.etaSec = -1;
        it.activeThreads = 0;
        switch (r.kind) {
            case COMPLETED:
                it.status = DownloadStatus.COMPLETED;
                it.completedAt = System.currentTimeMillis();
                it.error = "";
                break;
            case PAUSED:
                it.status = shutdown && config.resumeOnStart ? DownloadStatus.QUEUED : DownloadStatus.PAUSED;
                break;
            default:
                it.status = DownloadStatus.FAILED;
                it.error = r.message;
                it.failedAt = System.currentTimeMillis();
                if (r.restart) { it.remaining = null; it.done = 0; }
                if (r.message != null && r.message.startsWith("Checksum")) it.autoRetries = config.autoRetryMax;
        }
        if (find(it.id) != null) store.save(it);
        Listener l = listener;
        if (l != null) {
            if (r.kind == DownloadJob.Kind.COMPLETED || r.kind == DownloadJob.Kind.FAILED) l.onItemFinished(it);
            l.onListChanged();
        }
        schedule();
    }

    private void tick() {
        try {
            long now = System.currentTimeMillis();
            boolean changed = false;
            if (config.autoRetryFailed && !paused && online) {
                for (DownloadItem it : items) {
                    if (it.status == DownloadStatus.FAILED && it.autoRetries < config.autoRetryMax
                            && now - it.failedAt > config.autoRetryDelayMs
                            && !it.error.startsWith("Login") && !it.error.startsWith("Not enough")
                            && !it.error.startsWith("Storage") && !it.error.startsWith("Cannot")) {
                        it.autoRetries++;
                        it.status = DownloadStatus.QUEUED;
                        store.save(it);
                        changed = true;
                    }
                }
            }
            if (changed) { fireList(); schedule(); }
            Listener l = listener;
            if (l != null) l.onTick();
        } catch (Throwable ignored) { }
    }

    private void deleteFiles(DownloadItem it, boolean includingFinal) {
        if (it.dir.isEmpty() || it.fileName.isEmpty()) return;
        new File(it.dir, it.fileName + ".part").delete();
        if (includingFinal) new File(it.dir, it.fileName).delete();
    }
}
