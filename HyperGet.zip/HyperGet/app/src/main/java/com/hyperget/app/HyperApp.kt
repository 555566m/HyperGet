package com.hyperget.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.BatteryManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.hyperget.core.Config
import com.hyperget.core.DownloadEngine
import com.hyperget.core.DownloadItem
import com.hyperget.core.DownloadStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.io.File

/** Immutable snapshot of a download for the UI. */
data class UiItem(
    val id: String, val name: String, val url: String, val status: DownloadStatus,
    val progress: Float, val done: Long, val total: Long, val speed: Double, val eta: Long,
    val error: String, val dir: String, val threads: Int, val activeThreads: Int,
    val category: String, val resumable: Boolean, val segMap: FloatArray, val speedLimitKb: Int,
    val createdAt: Long, val checksumResult: String,
)

class HyperApp : Application(), DownloadEngine.Listener {
    lateinit var prefs: Prefs
    lateinit var engine: DownloadEngine
    lateinit var net: NetMonitor

    private val _items = MutableStateFlow<List<UiItem>>(emptyList())
    val items: StateFlow<List<UiItem>> = _items
    private val _speed = MutableStateFlow(0.0)
    val speed: StateFlow<Double> = _speed
    private val _online = MutableStateFlow(true)
    val online: StateFlow<Boolean> = _online
    private val speedHistory = ArrayDeque<Float>()
    fun history(): List<Float> = synchronized(speedHistory) { speedHistory.toList() }
    private var lastServiceKick = 0L

    override fun onCreate() {
        super.onCreate()
        instance = this
        prefs = Prefs(this)
        createChannels()
        val cfg = Config()
        prefs.apply(cfg)
        engine = DownloadEngine(File(filesDir, "items"), cfg, this)
        net = NetMonitor(this) { refreshOnline() }
        net.start()
        refreshOnline()
        Scheduler.apply(this)
        if (prefs.schedEnabled && !Scheduler.insideWindow(prefs)) engine.pauseAll()
        publish()
        if (engine.hasActive()) startServiceSafe()
    }

    fun applyPrefs() {
        prefs.apply(engine.config)
        refreshOnline()
    }

    fun batteryLow(): Boolean {
        val min = prefs.minBattery
        if (min <= 0) return false
        val bm = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val lvl = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val charging = bm.isCharging
        return !charging && lvl in 1 until min
    }

    fun refreshOnline() {
        val ok = net.connected && (!prefs.wifiOnly || net.wifi) && !batteryLow()
        _online.value = ok
        engine.setOnline(ok)
    }

    // ------------------------------------------------------ engine callbacks

    override fun onListChanged() {
        publish()
        if (engine.hasActive()) startServiceSafe()
    }

    override fun onTick() {
        refreshOnlineIfBatteryRule()
        publish()
        if (engine.hasActive() && System.currentTimeMillis() - lastServiceKick > 15_000) startServiceSafe()
    }

    private fun refreshOnlineIfBatteryRule() {
        if (prefs.minBattery > 0) refreshOnline()
    }

    override fun onItemFinished(item: DownloadItem) {
        val nm = getSystemService(NotificationManager::class.java)
        val ok = item.status == DownloadStatus.COMPLETED
        val b = NotificationCompat.Builder(this, if (ok) CH_DONE else CH_ERR)
            .setSmallIcon(if (ok) android.R.drawable.stat_sys_download_done else android.R.drawable.stat_notify_error)
            .setContentTitle(if (ok) "Download complete" else "Download failed")
            .setContentText(if (ok) item.fileName else item.fileName.ifEmpty { item.url } + " — " + item.error)
            .setAutoCancel(true)
            .setContentIntent(PendingIntent.getActivity(this, item.id.hashCode(),
                Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
        if (ok) {
            Open.viewIntent(this, File(item.dir, item.fileName))?.let {
                b.setContentIntent(PendingIntent.getActivity(this, item.id.hashCode(), it,
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
            }
        }
        try { nm.notify(10_000 + (item.id.hashCode() and 0xffff), b.build()) } catch (_: SecurityException) { }
        if (prefs.notifyVibrate) {
            try {
                val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                v.vibrate(VibrationEffect.createOneShot(200, VibrationEffect.DEFAULT_AMPLITUDE))
            } catch (_: Throwable) { }
        }
    }

    private fun publish() {
        val list = engine.items().asReversed().map { toUi(it) }
        _items.value = list
        var sp = 0.0
        for (i in list) if (i.status == DownloadStatus.DOWNLOADING) sp += i.speed
        _speed.value = sp
        if (engine.hasActive()) {
            synchronized(speedHistory) {
                speedHistory.addLast(sp.toFloat())
                while (speedHistory.size > 90) speedHistory.removeFirst()
            }
        }
    }

    private fun toUi(it: DownloadItem) = UiItem(
        it.id,
        it.fileName.ifEmpty { com.hyperget.core.Util.fileNameFromUrl(it.url).ifEmpty { it.url } },
        it.url, it.status, it.progress(), it.done, it.total, it.speed, it.etaSec, it.error, it.dir,
        it.threads, it.activeThreads, it.category, it.resumable,
        if (it.status.isRunning) it.segmentMap(60) else FloatArray(0),
        it.speedLimit / 1024, it.createdAt, it.checksumResult,
    )

    fun startServiceSafe() {
        lastServiceKick = System.currentTimeMillis()
        try {
            ContextCompat.startForegroundService(this, Intent(this, DownloadService::class.java))
        } catch (_: Throwable) { }
    }

    private fun createChannels() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_PROGRESS, "Download progress", NotificationManager.IMPORTANCE_LOW).apply { setShowBadge(false) })
        nm.createNotificationChannel(NotificationChannel(CH_DONE, "Completed downloads", NotificationManager.IMPORTANCE_DEFAULT).apply {
            if (!prefs.notifySound) setSound(null, null)
        })
        nm.createNotificationChannel(NotificationChannel(CH_ERR, "Download errors", NotificationManager.IMPORTANCE_DEFAULT))
    }

    companion object {
        const val CH_PROGRESS = "progress"
        const val CH_DONE = "done"
        const val CH_ERR = "error"
        lateinit var instance: HyperApp
            private set
    }
}
