package com.hyperget.app

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities

/** Tracks the default network. "Online" = has internet capability (the engine itself handles flaky links). */
class NetMonitor(ctx: Context, private val onChange: () -> Unit) {
    private val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    @Volatile var connected = false; private set
    @Volatile var wifi = false; private set

    private val cb = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) { read(network); onChange() }
        override fun onLost(network: Network) { connected = false; wifi = false; onChange() }
        override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) { apply(caps); onChange() }
    }

    fun start() {
        try {
            cm.registerDefaultNetworkCallback(cb)
        } catch (_: Throwable) { }
        read(cm.activeNetwork)
    }

    private fun read(n: Network?) {
        val caps = if (n != null) cm.getNetworkCapabilities(n) else null
        if (caps == null) { connected = false; wifi = false } else apply(caps)
    }

    private fun apply(caps: NetworkCapabilities) {
        connected = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        wifi = caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
                caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) ||
                caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)
    }
}
