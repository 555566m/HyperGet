package com.hyperget.core;

/** Lifecycle of one download. */
public enum DownloadStatus {
    QUEUED, CONNECTING, DOWNLOADING, WAITING_NETWORK, PAUSED, VERIFYING, COMPLETED, FAILED;

    public boolean isRunning() {
        return this == CONNECTING || this == DOWNLOADING || this == WAITING_NETWORK || this == VERIFYING;
    }
}
