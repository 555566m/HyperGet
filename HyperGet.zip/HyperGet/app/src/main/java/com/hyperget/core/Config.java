package com.hyperget.core;

/** Global engine settings. All fields are volatile so they can be changed while downloads run. */
public final class Config {
    public volatile int maxConcurrent = 3;             // simultaneous downloads
    public volatile int defaultThreads = 8;            // connections per download
    public volatile int maxThreads = 32;
    public volatile long minSplitBytes = 1L << 20;     // a segment is only split if both halves stay >= this
    public volatile int connectTimeoutMs = 20_000;
    public volatile int readTimeoutMs = 25_000;
    public volatile long giveUpAfterMs = 20 * 60_000L; // no progress for this long (while online) => FAILED. 0 = never
    public volatile long globalSpeedLimit = 0;         // bytes/s, 0 = unlimited
    public volatile String userAgent =
            "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36";
    public volatile boolean preallocate = true;        // "create empty file" - faster, fails early when disk is full
    public volatile boolean allowInsecureSsl = false;
    public volatile String proxyHost = "";
    public volatile int proxyPort = 0;
    public volatile boolean proxySocks = false;
    public volatile ConflictPolicy conflict = ConflictPolicy.RENAME;
    public volatile boolean autoRetryFailed = true;    // re-queue failed downloads automatically
    public volatile int autoRetryMax = 20;
    public volatile long autoRetryDelayMs = 45_000;
    public volatile boolean resumeOnStart = true;      // queued/running downloads continue after app/phone restart
    public volatile String defaultDir = "";
}
