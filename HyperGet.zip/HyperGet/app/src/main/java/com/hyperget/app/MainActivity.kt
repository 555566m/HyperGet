package com.hyperget.app

import android.Manifest
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.hyperget.core.DownloadRequest

class MainActivity : ComponentActivity() {
    private val addState = mutableStateOf<AddPrefill?>(null)
    private lateinit var browser: BrowserState
    private var lastClip = ""
    private lateinit var app: HyperApp

    private val exportLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) try {
            contentResolver.openOutputStream(uri)?.use { os ->
                os.write(app.engine.items().joinToString("\n") { it.url }.toByteArray())
            }
            Toast.makeText(this, "Exported", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) { Toast.makeText(this, "Export failed: ${e.message}", Toast.LENGTH_LONG).show() }
    }
    private val importLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) try {
            val text = contentResolver.openInputStream(uri)?.bufferedReader()?.readText() ?: ""
            val urls = UrlUtil.extract(text)
            for (u in urls) app.engine.add(DownloadRequest(u))
            Toast.makeText(this, "Imported ${urls.size} link(s)", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) { Toast.makeText(this, "Import failed: ${e.message}", Toast.LENGTH_LONG).show() }
    }
    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        app = application as HyperApp
        browser = BrowserState(this) { addState.value = it }
        if (Build.VERSION.SDK_INT >= 33) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        handleIntent(intent)

        setContent {
            var themeTick by remember { mutableIntStateOf(0) }
            var screen by remember { mutableStateOf(Screen.HOME) }
            var askStorage by remember { mutableStateOf(!app.prefs.askedStorage && !Storage.hasAllFiles() && Build.VERSION.SDK_INT >= 30) }
            val pre by addState
            val tick = themeTick
            val dark = when (app.prefs.theme) { 0 -> isSystemInDarkTheme(); 1 -> true; else -> false }
            val accent = Accents[app.prefs.accent.coerceIn(0, Accents.size - 1)]

            HyperTheme(dark, accent) {
                key(tick) {
                    BackHandler(enabled = screen != Screen.HOME) {
                        if (screen == Screen.BROWSER && browser.canBack) browser.web.goBack() else screen = Screen.HOME
                    }
                    AppBackground {
                        Box(Modifier.fillMaxSize()) {
                            when (screen) {
                                Screen.HOME -> HomeScreen(app)
                                Screen.BROWSER -> BrowserScreen(browser, app.prefs.homePage)
                                Screen.TOOLS -> ToolsScreen(app, { screen = it }, { pasteFromClipboard() },
                                    { exportLauncher.launch("hyperget-downloads.txt") },
                                    { importLauncher.launch(arrayOf("text/plain", "text/*")) }, { themeTick++ })
                                Screen.SETTINGS -> SettingsScreen(app)
                                Screen.SCHEDULER -> SchedulerScreen(app)
                                Screen.STATS -> StatsScreen(app)
                            }
                        }
                        if (screen == Screen.HOME) {
                            Box(Modifier.align(Alignment.BottomEnd).navigationBarsPadding().padding(end = 20.dp, bottom = 96.dp)
                                .clickable { addState.value = AddPrefill() }) { Img3D("add", 68.dp) }
                        }
                        BottomBar(screen) { screen = it }
                    }
                    if (pre != null) AddDownloadSheet(app, pre!!) { addState.value = null }
                    if (askStorage) {
                        AlertDialog(
                            onDismissRequest = { askStorage = false; app.prefs.askedStorage = true },
                            title = { Text("Save to your Downloads folder?") },
                            text = { Text("Allow \"all files access\" so HyperGet can save into Downloads/HyperGet. Without it, files are saved inside the app's own folder.") },
                            confirmButton = {
                                TextButton({
                                    askStorage = false; app.prefs.askedStorage = true
                                    try {
                                        startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
                                    } catch (_: Throwable) { }
                                }) { Text("Allow") }
                            },
                            dismissButton = { TextButton({ askStorage = false; app.prefs.askedStorage = true }) { Text("Later") } },
                        )
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        app.applyPrefs()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && app.prefs.clipboardWatch && addState.value == null) {
            val t = readClip()
            if (t.isNotEmpty() && t != lastClip && UrlUtil.looksLikeLink(t)) {
                lastClip = t
                addState.value = AddPrefill(text = t)
            }
        }
    }

    override fun onDestroy() {
        browser.destroy()
        super.onDestroy()
    }

    private fun readClip(): String = try {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString()?.trim() ?: ""
    } catch (_: Throwable) { "" }

    private fun pasteFromClipboard() {
        val t = readClip()
        if (t.isEmpty()) Toast.makeText(this, "Clipboard is empty", Toast.LENGTH_SHORT).show()
        else { lastClip = t; addState.value = AddPrefill(text = t) }
    }

    private fun handleIntent(i: Intent?) {
        val text = when (i?.action) {
            Intent.ACTION_SEND -> i.getStringExtra(Intent.EXTRA_TEXT)
            Intent.ACTION_VIEW -> i.dataString
            else -> null
        }
        if (!text.isNullOrBlank()) { lastClip = text; addState.value = AddPrefill(text = text) }
    }
}

@androidx.compose.runtime.Composable
private fun androidx.compose.foundation.layout.BoxScope.BottomBar(current: Screen, go: (Screen) -> Unit) {
    val p = LocalPal.current
    val items = listOf(
        Triple(Screen.HOME, "Downloads", "download"), Triple(Screen.BROWSER, "Browser", "browser"),
        Triple(Screen.TOOLS, "Tools", "speed"), Triple(Screen.SETTINGS, "Settings", "settings"),
    )
    Row(
        Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(horizontal = 16.dp, vertical = 10.dp)
            .clip(RoundedCornerShape(30.dp)).background(p.card.copy(alpha = 0.96f))
            .border(1.dp, p.border, RoundedCornerShape(30.dp)).padding(horizontal = 8.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
    ) {
        for ((s, label, ic) in items) {
            val sel = current == s || (s == Screen.TOOLS && (current == Screen.SCHEDULER || current == Screen.STATS))
            Column(
                Modifier.weight(1f).clip(RoundedCornerShape(20.dp)).clickable { go(s) }
                    .background(if (sel) p.accent.copy(alpha = 0.18f) else androidx.compose.ui.graphics.Color.Transparent).padding(vertical = 6.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Img3D(ic, if (sel) 38.dp else 32.dp)
                Text(label, color = if (sel) p.text else p.sub, fontSize = 11.sp, fontWeight = if (sel) FontWeight.Bold else FontWeight.Medium)
            }
        }
    }
}
