package com.hyperget.core;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.util.Base64;
import java.util.Map;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

final class Http {
    private Http() {}

    static final class Response {
        final HttpURLConnection conn;
        final int code;
        final String url;

        Response(HttpURLConnection conn, int code, String url) {
            this.conn = conn;
            this.code = code;
            this.url = url;
        }

        void close() {
            try { conn.disconnect(); } catch (Throwable ignored) { }
        }
    }

    private static SSLSocketFactory trustAllFactory;
    private static final HostnameVerifier ALLOW_ALL = (h, s) -> true;

    private static synchronized SSLSocketFactory trustAll() throws IOException {
        if (trustAllFactory == null) {
            try {
                TrustManager[] tm = {new X509TrustManager() {
                    public void checkClientTrusted(X509Certificate[] c, String a) { }
                    public void checkServerTrusted(X509Certificate[] c, String a) { }
                    public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
                }};
                SSLContext ctx = SSLContext.getInstance("TLS");
                ctx.init(null, tm, new SecureRandom());
                trustAllFactory = ctx.getSocketFactory();
            } catch (Exception e) {
                throw new IOException(e);
            }
        }
        return trustAllFactory;
    }

    /** Opens {@code startUrl}, following redirects by hand. {@code from<0} = no Range header. */
    static Response get(Config cfg, DownloadItem it, String startUrl, long from, long to, String ifRange) throws IOException {
        String cur = Util.normalizeUrl(startUrl);
        String origHost = hostOf(it.url);
        for (int i = 0; i < 12; i++) {
            HttpURLConnection c = create(cfg, it, cur, from, to, ifRange, hostOf(cur).equalsIgnoreCase(origHost));
            int code;
            try {
                code = c.getResponseCode();
            } catch (IOException e) {
                try { c.disconnect(); } catch (Throwable ignored) { }
                throw e;
            }
            if (code == 301 || code == 302 || code == 303 || code == 307 || code == 308) {
                String loc = c.getHeaderField("Location");
                c.disconnect();
                if (loc == null) throw new IOException("Redirect without Location");
                cur = Util.normalizeUrl(new URL(new URL(cur), loc).toString());
                continue;
            }
            return new Response(c, code, cur);
        }
        throw new IOException("Too many redirects");
    }

    private static String hostOf(String u) {
        try { return new URL(u).getHost(); } catch (Exception e) { return ""; }
    }

    private static HttpURLConnection create(Config cfg, DownloadItem it, String url, long from, long to,
                                            String ifRange, boolean sameHost) throws IOException {
        URL u = new URL(url);
        HttpURLConnection c;
        String ph = cfg.proxyHost;
        if (ph != null && !ph.isEmpty() && cfg.proxyPort > 0) {
            Proxy p = new Proxy(cfg.proxySocks ? Proxy.Type.SOCKS : Proxy.Type.HTTP,
                    InetSocketAddress.createUnresolved(ph, cfg.proxyPort));
            c = (HttpURLConnection) u.openConnection(p);
        } else {
            c = (HttpURLConnection) u.openConnection();
        }
        c.setInstanceFollowRedirects(false);
        c.setConnectTimeout(cfg.connectTimeoutMs);
        c.setReadTimeout(cfg.readTimeoutMs);
        c.setUseCaches(false);
        c.setRequestProperty("Accept", "*/*");
        c.setRequestProperty("Accept-Encoding", "identity");
        c.setRequestProperty("Connection", "keep-alive");
        String ua = it.userAgent == null || it.userAgent.isEmpty() ? cfg.userAgent : it.userAgent;
        c.setRequestProperty("User-Agent", ua);
        if (it.referer != null && !it.referer.isEmpty()) c.setRequestProperty("Referer", it.referer);
        if (it.cookie != null && !it.cookie.isEmpty()) c.setRequestProperty("Cookie", it.cookie);
        for (Map.Entry<String, String> h : it.headers.entrySet()) c.setRequestProperty(h.getKey(), h.getValue());
        if (sameHost && it.authUser != null && !it.authUser.isEmpty()) {
            String tok = Base64.getEncoder().encodeToString(
                    (it.authUser + ":" + it.authPass).getBytes(StandardCharsets.UTF_8));
            c.setRequestProperty("Authorization", "Basic " + tok);
        }
        if (from >= 0) {
            c.setRequestProperty("Range", "bytes=" + from + "-" + (to >= 0 && to != Long.MAX_VALUE ? to : ""));
            if (ifRange != null && !ifRange.isEmpty() && from > 0) c.setRequestProperty("If-Range", ifRange);
        }
        if (c instanceof HttpsURLConnection && cfg.allowInsecureSsl) {
            ((HttpsURLConnection) c).setSSLSocketFactory(trustAll());
            ((HttpsURLConnection) c).setHostnameVerifier(ALLOW_ALL);
        }
        return c;
    }

    static long retryAfterMs(HttpURLConnection c) {
        try {
            String v = c.getHeaderField("Retry-After");
            if (v != null) return Math.min(120_000, Long.parseLong(v.trim()) * 1000);
        } catch (Exception ignored) { }
        return 0;
    }
}
