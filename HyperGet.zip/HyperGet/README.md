# HyperGet – powerful Android download manager

ADM jaisa multi-connection downloader, modern dark UI aur 3D icons ke saath.

## APK kaise banaye (phone se bhi)
1. GitHub par naya repo banao aur is poore folder ko upload/push karo.
2. Repo → **Actions → Build APK → Run workflow**.
3. Khatam hone par **Artifacts → HyperGet-apk** download karo, APK install karo.

(PC par: Android Studio me folder kholo → Build → Build APK. JDK 17, Android SDK 34.)

## Features
- Multi-connection (1–32) + **dynamic re-splitting**: jaise hi koi connection free hota hai, sabse bada bacha hissa aadha ho kar naye connection ko mil jata hai
- **Resume byte-exact**: pause, app kill, phone reboot, network drop – sab ke baad wahi se
- Network gaya to "Waiting for network" me ruk kar apne aap wapas chalta hai (failure count nahi hota)
- Error/503/connection-reset par backoff ke saath infinite retry; zyada errors par connections kam, stable hone par wapas badhte hain
- Expired/403 link par original link se **re-resolve**; mirrors support
- Redirects, Content-Disposition naam, auth, cookies, referer, user-agent, proxy, SSL-ignore option
- Queue (simultaneous limit), per-download aur global speed limit, auto-retry failed
- Foreground service + wake lock + Wi-Fi lock (heavy download background me bhi chalta rahe), boot par queue restore
- Scheduler (daily start/stop), Wi-Fi only, low-battery pause
- Built-in browser: download pakadta hai, page ki video/audio files detect karta hai, cookies/referer saath bhejta hai
- Clipboard watcher, share-to-app, link intercept (common file types), multi-link add
- Checksum (MD5/SHA-256) verify, rename, share, open, import/export list (.txt), stats graph
- Tools hub (screenshot jaise rangeen tiles), theme + accent colours

## Abhi shamil nahi
- Torrent/magnet (ADM native libtorrent use karta hai) aur HLS (.m3u8) merge

## Tests
`tools/engine-test/` me fault-injecting server aur Java test hain (random connection kill, 503, no-range, pause + restart, offline, speed limit, queue). Chalane ke liye:
```
python3 tools/engine-test/server.py 8765 &
javac -d out app/src/main/java/com/hyperget/core/*.java tools/engine-test/EngineTest.java
java -cp out EngineTest
```
3D icons dobara banane ke liye: `python3 tools/icons/gen_icons.py <output-dir>`
